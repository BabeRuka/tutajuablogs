<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$url = $this->config->item('base_url');
$blog=$this->uri->segment(3);
?>
<div class="container">
<div class="row">
<div class="col-md-8">
  <div class="row">
<ol>
  <?php 
	  foreach ($grouped_categories as $k=>$v) {; 
		 if ( $this->uri->segment(3) ) {
			$link = $url.'categories/category/'.$this->uri->segment(3).'/'.$v['blog_category_slug']; 
		}else{
			$blog_id=$this->uri->segment(3,0);
			$link = $url.'categories/category/'.$blog_id.'/'.$v['blog_category_slug']; 
		}
	    //echo '<h1>'.$this->uri->segment(3).' A PHP Error was encountered</h1>'; 
	   ?>
  <h3>
    <li><a href="<?php echo $link; ?>" alt="<?php echo $v['TotalArticles']; ?> Articles in the <?php echo $v['blog_category_name']; ?> Categories" title="<?php echo $v['TotalArticles']; ?> Articles in the <?php echo $v['blog_category_name']; ?> Categories" ><?php echo $v['blog_category_name']; ?> (<?php echo $v['TotalArticles']; ?> Articles)</a></li>
  </h3>
  <?php } ?>
</ol>
<?php if ($this->uri->segment(2) == 'category') { ?>
<?php if ( !is_int($this->uri->segment(3)) ) {  
		echo '<h1>Category Results for '.str_replace('-', ' ', $this->uri->segment(4)).'</h1>'; 
	}else{
		if( $this->uri->segment(3) == '0'  ){
			echo '<h1>Category Results for '.str_replace('-', ' ', $this->uri->segment(4)).'</h1>'; 
		}else{
			echo '<h1>Category Results for '.str_replace('-', ' ', $this->uri->segment(3)).'</h1>'; 
		}
	}
	?>
<?php if (count($category_articles) > 0) {  ?>
<?php foreach ($category_articles as $k=>$v) {; ?>
<div class="col-md-12 well">
  <h3><?php echo ''.$v['blog_articles_pagetitle'].''; ?></h3>
  <?php if ($v['blog_articles_image']){ ?><div> <img src="<?php echo $url.'assets/images/articles/'.$v['blog_articles_image'].''; ?>"  align="left" border="2"  class="img-thumbnail my-pic" /> </div><?php } ?>
  <div> <?php echo $v['blog_articles_shortdesc']; ?>
    <div style="margin-top:2%;">
      <div class="btn btn-default"><a href="<?php echo ''.$url.'out/index/'.$v['blog_id'].'/'.$v['blog_articles_id'].''; ?> ">Readmore</a></div>
      <div class="btn btn-default"><?php echo $v['blog_article_hits']; ?> Hits</div>
    </div>
  </div>
  </div>
  <?php } } } ?>

</div>
</div>