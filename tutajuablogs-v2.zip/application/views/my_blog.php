<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="container">
<div class="row">
<div class="col-md-8">
  <div class="row">
  <?php if (count($my_blog) > 0) {  ?>
    <?php foreach ($my_blog as $k=>$v) {; ?>
    <div class="col-md-12 well"> <?php echo '<h2>'.$v['blog_articles_pagetitle'].'</h2>'; ?>
      <div><?php if ($v['blog_articles_image']){ ?><img src="<?php echo $url.'assets/images/articles/'.$v['blog_articles_image'].''; ?>" align="left" border="2"  class="img-thumbnail my-pic"  /><?php } ?></div>
      <div><?php echo strip_tags(substr($v['blog_articles_shortdesc'], 0,600)); ?></div>
      <div style="margin-top:2%;">
        <div class="btn btn-default"><?php echo  $v['blog_article_hits'].''; ?> Hits</div>
        <div class="btn btn-default"><a href="<?php echo $url.'out/index/'.$v['blog_id'].'/'.$v['blog_articles_id'].''; ?> ">Readmore</a></div>
      </div>
    </div>
    <?php } ?>
  </div>
  <?php }  ?>
</div>
