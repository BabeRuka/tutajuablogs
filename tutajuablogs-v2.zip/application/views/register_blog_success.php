<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$url = $this->config->item('base_url');
?>

<div class="leftcontent" style="width:98%;">
<h3>Your Registeration Process was successfully Completed!</h3>
</div>
