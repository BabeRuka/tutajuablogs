<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$url = $this->config->item('base_url');
?>

<div class="col-xs-7 well">
  <div align="center"><strong><?php echo $success; ?></strong></div>
  <?php echo form_open(''.$url.'password/reset'); ?>
  <div>
    <h5>Email Address</h5>
    <?php //echo $email_error; ?>
    <?php echo form_error('blog_email'); ?>
    <input type="text" name="blog_email" class="form-control" value="<?php echo set_value('blog_email'); ?>" size="50" />
  </div>
  <div style="margin-top:2%; margin-bottom:2%;">
    <input type="submit" value="Submit" class="btn btn-default"/>
  </div>
  </form>
</div>
</div>