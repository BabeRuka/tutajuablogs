<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$url = $this->config->item('base_url');
$blog=$this->uri->segment(3);
?>

<div class="col-xs-7  well left">
  <?php echo '<div class="btn btn-success" >Search Results for: <strong>'.$keyword.'</strong></div>'; ?>
  <?php foreach ($detailed_search_articles as $k=>$v) {; ?>
  <div class="col-12 "> 
  <h3><?php echo str_replace($keyword, '<span style="background-color:yellow; padding:2px;">'.$keyword.'</span>', $v['blog_articles_pagetitle']); ?></h3>
  <p>Posted on <strong  id="h3"><?php echo $v['blog_article_date']; ?></strong> by <strong  id="h3"><?php echo $v['blog_fname']; ?> <?php echo $v['blog_lname']; ?></strong> in <strong> <?php echo $v['blog_articles_catergory']; ?></strong></p>
  <p><?php echo  str_replace($keyword, '<span style="background-color:yellow; padding:2px;">'.$keyword.'</span>', $v['blog_articles_description']); ?></p>
  </div>
  <?php } ?>
</div>
