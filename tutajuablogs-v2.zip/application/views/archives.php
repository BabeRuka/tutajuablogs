<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$url = $this->config->item('base_url');
?>

<div class="container">
<div class="row">
<div class="col-md-8">
  <div class="row">
    <div class="col-md-12 well">
      <ol>
      <?php if (count($my_archives) > 0) {  ?>
        <?php  foreach ($my_archives as $k=>$v) {; 
			if ($v['MonthPublished'] == 1 ) { $month = 'January';  }
			else if ($v['MonthPublished'] == 2 ) { $month = 'February';  }
			else if ($v['MonthPublished'] == 3 ) { $month = 'March';  }
			else if ($v['MonthPublished'] == 4 ) { $month = 'April';  }
			else if ($v['MonthPublished'] == 5 ) { $month = 'May';  }
			else if ($v['MonthPublished'] == 6 ) { $month = 'June';  }
			else if ($v['MonthPublished'] == 7 ) { $month = 'July';  }
			else if ($v['MonthPublished'] == 8 ) { $month = 'August';  }
			else if ($v['MonthPublished'] == 9 ) { $month = 'September';  }
			else if ($v['MonthPublished'] == 10 ) { $month = 'October';  }
			else if ($v['MonthPublished'] == 11 ) { $month = 'November';  }
			else if ($v['MonthPublished'] == 12 ) { $month = 'December';  }
		?>
        <h3>
          <li><a href="<?php echo $url; echo 'archives/article/'.$blog_id.'/'; echo $v['YearPublished']; ?>/<?php echo $v['MonthPublished']; ?>" alt="<?php echo $v['ArticlesPublished']; ?> Articles Published for the month of <?php echo $month; echo $v['YearPublished']; ?>" title="<?php echo $v['ArticlesPublished']; ?> Articles Published for the month of <?php echo $v['MonthPublished']; ?>" ><?php echo $v['FullDate']; ?> (<?php echo $v['ArticlesPublished']; ?> Articles)</a></li>
        </h3>
        <?php } ?>
        <?php }  ?>
      </ol>
    </div>
  </div>
</div>
