<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="container">
<div class="row">
<div class="col-md-8">
  <div class="row">
  <div class="col-md-12 well">
   <?php if (count($article) > 0) {  ?> 
  <?php foreach ($article as $k=>$v) {; ?>
  <h3><?php echo $v['blog_articles_pagetitle']; ?></h3>
  <p>Posted on <strong  id="h3"><?php echo $v['blog_article_date']; ?></strong> by <strong  id="h3"><?php echo $v['blog_fname']; ?> <?php echo $v['blog_lname']; ?></strong> in <strong> <?php echo $v['blog_articles_catergory']; ?></strong></p>
  <p><?php echo stripslashes($v['blog_articles_description']); ?></p>
  <?php } ?>
  
<div class="row">
<div class="col-sm-12">
<h3>Comments</h3>
</div><!-- /col-sm-12 -->
</div><!-- /row -->


<div class="row">
<?php foreach ($my_blog_comments as $k=>$v) {; ?>
<div class="col-sm-1">
<div class="thumbnail">
<img class="img-responsive user-photo" src="<?php echo $this->config->item('base_url').'assets/images/'; ?>avatar.png">
</div><!-- /thumbnail -->
</div><!-- /col-sm-1 -->

<div class="col-sm-5">
<div class="panel panel-default">
<div class="panel-heading">
<strong><?php echo $v['blog_comment_name']; ?></strong> <span class="text-muted">Comment on <?php echo $v['blog_comment_date']; ?></span>
</div>
<div class="panel-body">
<?php echo $v['blog_comment_comment']; ?>
</div><!-- /panel-body -->
</div><!-- /panel panel-default -->
</div><!-- /col-sm-5 -->

 <?php } ?>
</div><!-- /row -->

  
 
  <!--make a comment-->
  <div class="table-responsive">
  <div><?php echo $message; ?></div>
	<form method="post" name="form1" action="">
  <table class="table" align="center">
    <tr valign="baseline">
      <td nowrap align="right">Name:</td>
      <td><input name="blog_comment_name" type="text" class="form-control" value="" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">Email:</td>
      <td><input name="blog_comment_email" type="text" class="form-control" value="" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right" valign="top">Comment:</td>
      <td><textarea name="blog_comment_comment" cols="50" rows="5" class="form-control"></textarea>
      </td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">&nbsp;</td>
      <td><input type="submit" class="btn btn-default" value="Make Comment"></td>
    </tr>
  </table>
  <input type="hidden" name="blog_comment_id" value="">
  <input type="hidden" name="blog_articles_id" value="<?php echo $article_id; ?>">
  <input type="hidden" name="blog_id" value="<?php echo $blog_id; ?>">
  <input type="hidden" name="blog_comment_date" value="">
  <input type="hidden" name="blog_comment_status" value="Pending">
  <input type="hidden" name="comment_insert" value="form1">
</form>
 <?php }  ?>
 </div>
 </div>
  </div>
 </div>