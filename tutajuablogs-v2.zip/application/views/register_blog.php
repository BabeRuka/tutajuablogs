<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$url = $this->config->item('base_url');
?>
<div class="container">
<div class="row">
<div class="col-md-8">
  <div class="row">
  <div class="col-md-12 well">
<?php //echo validation_errors(); ?>
<div align="center"><strong>Please Fill in Your Personal Details Below:</strong></div>
<?php echo form_open(''.$url.'register/index'); ?>

<h5>Username</h5>
<?php echo form_error('blog_username'); ?>
<input type="text" name="blog_username" class="form-control" value="<?php echo set_value('blog_username'); ?>" size="50" />

<h5>Password</h5>
<?php echo form_error('blog_password'); ?>
<input type="password" name="blog_password" class="form-control" value="<?php echo set_value('blog_password'); ?>" size="50" />

<h5>Password Confirm</h5>
<?php echo form_error('blog_password_confirm'); ?>
<input type="password" name="blog_password_confirm" class="form-control" value="<?php echo set_value('blog_password_confirm'); ?>" size="50" />

<h5>First Name</h5>
<?php echo form_error('blog_fname'); ?>
<input type="text" name="blog_fname" class="form-control" value="<?php echo set_value('blog_fname'); ?>" size="50" />

<h5>Last Name</h5>
<?php echo form_error('blog_lname'); ?>
<input type="text" name="blog_lname" class="form-control" value="<?php echo set_value('blog_lname'); ?>" size="50" />

<h5>Email Address</h5>
<?php echo form_error('blog_email'); ?>
<input type="text" name="blog_email" class="form-control" value="<?php echo set_value('blog_email'); ?>" size="50" />

<h5>The Name of Your Page</h5>
<?php echo form_error('blog_pagetitle'); ?>
<input type="text" name="blog_pagetitle" class="form-control" value="<?php echo set_value('blog_pagetitle'); ?>" size="50" />

<h5>A Short Description of Your Blog</h5>
<?php echo form_error('blog_description'); ?>
<textarea name="blog_description" rows="10" class="form-control" value="<?php echo set_value('blog_description'); ?>" ></textarea>


<div style="margin-top:2%"><input type="submit" class="btn btn-default" value="Submit" /></div>

<input type="hidden" name="blog_id" value="" />
<input type="hidden" name="blog_level" value="Yet to be Administered" />
<input type="hidden" name="blog_activicationkey" value="<?php $activationKey =  mt_rand() . mt_rand() . mt_rand() . mt_rand() . mt_rand(); ?>" />

</form>
</div>
</div>
</div>