<?php

echo 'You cannot edit this Article';
?>


</div>
