<?php
if ($this->session){
	/*
	
	tutajua_blog_comments.blog_comment_id,
tutajua_blog_comments.blog_articles_id,
tutajua_blog_comments.blog_id,
tutajua_blog_comments.blog_comment_date,
tutajua_blog_comments.blog_comment_name,
tutajua_blog_comments.blog_comment_email,
tutajua_blog_comments.blog_comment_comment,
	
	*/
}
foreach ($comments as $k=>$v){
		$blog_comment_id= $v['blog_comment_id'];
		$blog_articles_id = $v['blog_articles_id'];
		$blog_id = $v['blog_id'];
		$blog_comment_date = $v['blog_comment_date'];
		$blog_comment_name = $v['blog_comment_name'];
		$blog_comment_email = $v['blog_comment_email'];
		$blog_comment_comment = $v['blog_comment_comment']; 
		$blog_comment_status = $v['blog_comment_status']; 

}
?>

<form action="" method="post" name="form1" id="form1">
  <table align="center">
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap">Comment Status:<br />
        <span style="font-size: x-small; font-weight: bold; font-style: italic">If you approve of the comment then choose<br /> 
      Addressed Otherwise Leave it on Pending</span></td>
      <td><select class="form-control"  name="blog_comment_status">
        <option value="Addressed" <?php if ($blog_comment_status == "Addressed") { echo 'selected= "SELECTED"'; } ?>>Addressed</option>
        <option value="Being Addressed"  <?php if ($blog_comment_status == "Being Addressed") { echo 'selected= "SELECTED"'; } ?>>Being Addressed</option>
        <option value="Pending"  <?php if ($blog_comment_status == "Pending") { echo 'selected= "SELECTED"'; } ?>>Pending</option>
      </select>
      </td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap">&nbsp;</td>
      <td><input type="submit" value="Update record" class="btn btn-default" /></td>
    </tr>
  </table>
  <input type="hidden" name="update_comment" value="form1" />
  <input type="hidden" name="blog_comment_id" value="<?php echo $blog_comment_id; ?>" />
</form>

</div>
