<?php

?>
<div align="center"><strong><?php echo $success; ?></strong></div> 
<div class="table-responsive">
  <table class="table table-striped">
    <tr >
      <td><div align="center" style="font-weight: bold">Comment</div></td>
      <td colspan="3"><div align="center" style="font-weight: bold">Actions</div></td>
    </tr>
    <?php foreach($comments as $comment) { ?>
    <tr >
      <td><?php echo $comment['blog_comment_comment']; ?><br />
        Posted on <?php echo  $comment['blog_comment_date']; ?> by <?php echo $comment['blog_comment_name']; ?></td>
      <td>This Comments Status is <?php echo  $comment['blog_comment_status']; ?></td>
      <td><div class="btn btn-default btn-xs"><span style="font-weight: bold"> 
      <a href="<?php echo $base_url.'admin/comments/edit/'.$comment['blog_comment_id'].''; ?>">Manage Comment</a></span></div></td>
      <td><div class="btn btn-default btn-xs"><span style="font-weight: bold">  
      <a href="<?php echo $base_url; ?>admin/comments/delete/<?php echo $comment['blog_comment_id']; ?>" onclick="return confirm('Are you sure you want to delete?')"  >Delete Comment</a></span></div></td>
    </tr>
    <?php } ?>
  </table>
</div>

