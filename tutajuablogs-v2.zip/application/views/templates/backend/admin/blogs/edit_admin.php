<?php
if ($this->session){
	//var_dump($admin_details);	
}
foreach ($admin_details as $k=>$v){
		$blog_id= $v['blog_id'];
		$blog_description= $v['blog_description'];
		$blog_page= $v['blog_page'];
		$blog_pagetitle= $v['blog_pagetitle'];
		$blog_username= $v['blog_username'];
		$blog_password= $v['blog_password'];
		$blog_fname= $v['blog_fname'];
		$blog_lname= $v['blog_lname'];
		$blog_email= $v['blog_email'];
		$blog_level= $v['blog_level'];
		$blog_catergory= $v['blog_catergory'];
}
?>

<form action="<?php echo $base_url; ?>admin/blogs/edit/<?php echo $blog_id; ?>" method="post" name="form2" id="form2">
  <table align="left" class="tablecontent1">
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap">Blog Page:</td>
      <td><input type="text" class="form-control" name="blog_page" value="<?php echo $blog_page; ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap">Blog Pagetitle:</td>
      <td><input type="text" class="form-control" name="blog_pagetitle" value="<?php echo $blog_pagetitle; ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap">Blog Username:</td>
      <td><input type="text" class="form-control" name="blog_username" value="<?php echo $blog_username; ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap">First Name:</td>
      <td><input type="text" class="form-control" name="blog_fname" value="<?php echo $blog_fname; ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap">Last Name:</td>
      <td><input type="text" class="form-control" name="blog_lname" value="<?php echo $blog_lname; ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap">Email Address:</td>
      <td><input type="text" class="form-control" name="blog_email" value="<?php echo $blog_email; ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right" valign="middle">A Description of your Blog:</td>
      <td><textarea  class="form-control"  name="blog_description" cols="50" rows="5"><?php echo $blog_description; ?></textarea>
      </td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap">&nbsp;</td>
      <td><input type="submit" class="btn btn-default" value="Update record" /></td>
    </tr>
  </table>
  <input type="hidden" name="blog_id" value="<?php echo $blog_id; ?>" />
  <input type="hidden" name="blog_update" value="form1" />
</form>
</form>
<!--end-->
</div>
