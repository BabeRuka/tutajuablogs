<?php
if ($this->session){
	//var_dump($admin_details);	
}
foreach ($admin_details as $k=>$v){
	$blog_fname = $v['blog_fname'];
	$blog_lname = $v['blog_lname'];
	$blog_level = $v['blog_level'];
	$blog_id = $v['blog_id'];
	$blog_catergory = $v['blog_catergory'];
}
?>

<form action="<?php echo $base_url; ?>admin/blogs/manage/<?php echo $blog_id; ?>" method="post" name="form2" id="form2">
  <table align="left">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Name:</td>
      <td><input name="username" type="readonly" id="username" value="<?php echo $blog_fname; echo ' '; echo $blog_lname; ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Blog Visibility:</td>
      <td><select class="form-control"  name="blog_level" id="blog_level">
              <option value='Approved' <?php if ($blog_level == 'Approved') {echo 'selected="selected"';} ?>>Approved</option>
            <option value='Not Approved' <?php if ($blog_level == 'Not Approved') {echo 'selected="selected"';} ?>>Not Approved</option>
            <option value='Yet to be Administered' <?php if ($blog_level == 'Yet to be Administered') {echo 'selected="selected"';} ?>>Yet to be Administered</option>

        </select></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Blog Role:</td>
      <td><select class="form-control"  name="blog_catergory" id="blog_catergory">
            <option value='Administrators' <?php if ($blog_catergory == 'Administrators') {echo 'selected="selected"';} ?>>Administrators</option>
            <option value='Associate' <?php if ($blog_catergory == 'Associate') {echo 'selected="selected"';} ?>>Associate</option>
            <option value='Lawyers' <?php if ($blog_catergory == 'Lawyers') {echo 'selected="selected"';} ?>>Lawyers</option>
            <option value='Partner' <?php if ($blog_catergory == 'Partner') {echo 'selected="selected"';} ?>>Partner</option>
            <option value='Staff' <?php if ($blog_catergory == 'Staff') {echo 'selected="selected"';} ?>>Staff</option>
            <option value='Super Administrator' <?php if ($blog_catergory == 'Super Administrator') {echo 'selected="selected"';} ?>>Super Administrator</option>
            <option value='User' <?php if ($blog_catergory == 'User') {echo 'selected="selected"';} ?>>User</option>
        </select></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td><input type="submit" value="Update record" class="btn btn-default" /></td>
    </tr>
  </table>
  <input type="hidden" name="blog_id" value="<?php echo $blog_id; ?>" />
  <input type="hidden" name="blog_update" value="form2" />
</form>
<!--end-->
</div>
