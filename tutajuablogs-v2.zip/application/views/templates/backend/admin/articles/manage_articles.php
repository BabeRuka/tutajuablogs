<?php

?>
<div align="center"><strong><?php echo $success; ?></strong></div> 

<div class="table-responsive">
  <table class="table table-striped">
    <tr>
      <td><div align="center" style="font-weight: bold">ID</div></td>
      <td><div align="center" style="font-weight: bold">Author</div></td>
      <td><div align="center" style="font-weight: bold">Title</div></td>
      <td>Featured Image</td>
      <td><div align="center" style="font-weight: bold">Article Status</div></td>
      <td><div align="center" style="font-weight: bold">Published Date</div></td>
      <td colspan="2"><div align="center" style="font-weight: bold">Actions</div></td>
    </tr>
    <?php foreach ($all_articles as $row_Articles){ ?>
    <tr >
      <td><a href="#"><?php echo $row_Articles['blog_articles_id']; ?></a></td>
      <td><a href="#"><?php echo $row_Articles['blog_fname']; ?> <?php echo $row_Articles['blog_lname']; ?></a></td>
      <td><a href="#"><?php echo $row_Articles['blog_articles_pagetitle']; ?></a></td>
      <td><a href="#">
        <?php if ($row_Articles['blog_articles_image']){ ?>
        <a href="<?php echo $this->config->item('base_url'); ?>featured/index/<?php echo $row_Articles['blog_articles_id']; ?>">
        <img src="<?php echo $this->config->item('base_url'); ?>assets/images/articles/<?php echo $row_Articles['blog_articles_image']; ?>" alt="Upload a Featured Image" title="Upload a Featured Image" alt="Upload a Featured Image" width="50" height="50" />
        </a>
        <?php }else{ ?>
        <div class="btn btn-default btn-xs">
        <a href="<?php echo $this->config->item('base_url'); ?>featured/index/<?php echo $row_Articles['blog_articles_id']; ?>">Upload Featured Image</a></div>
        <?php } ?>
        </a></td>
      <td><a href="#"><?php echo $row_Articles['blog_articles_level']; ?></a></td>
      <td><a href="#"><?php echo $row_Articles['blog_article_date']; ?></a></td>
      <td><div class="btn btn-default btn-xs"><span style="font-weight: bold"><a href="<?php echo $base_url; ?>admin/articles/edit/<?php echo $row_Articles['blog_articles_id']; ?>">Edit</a></span></div></td>
      <td><div class="btn btn-default btn-xs"><span style="font-weight: bold"><a href="<?php echo $base_url; ?>admin/articles/delete/<?php echo $row_Articles['blog_articles_id']; ?>"onclick="return confirm('Are you sure you want to delete?')">Delete</a></span></div></td>
    </tr>
    <?php }  ?>
  </table>
</div>
