<?php
if ($this->session){
	//var_dump($admin_details);	
}
foreach ($article_details as $k=>$v){
		$blog_id= $v['blog_id'];
		$blog_category_id = $v['blog_category_id'];
		$blog_articles_id = $v['blog_articles_id'];
		$blog_articles_page = $v['blog_articles_page'];
		$blog_articles_pagetitle = $v['blog_articles_pagetitle'];
		$blog_category_name = $v['blog_category_name'];
		$blog_articles_level= $v['blog_articles_level'];
		$blog_username= $v['blog_username'];
		$blog_articles_shortdesc= $v['blog_articles_shortdesc'];
		$blog_fname= $v['blog_fname'];
		$blog_lname= $v['blog_lname'];
		$blog_email= $v['blog_email'];
		$blog_level= $v['blog_level'];
		$blog_articles_description = $v['blog_articles_description'];
		$blog_articles_shortdesc = $v['blog_articles_shortdesc'];
}
?>


<form method="post" name="form1" action="<?php echo $base_url; ?>admin/articles/edit">
  <table align="center">
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap>Name of Article Page:</td>
      <td><input type="text" class="form-control" name="blog_articles_page" value="<?php echo $blog_articles_page; ?>" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap>Pagetitle of Article:</td>
      <td><input type="text" class="form-control" name="blog_articles_pagetitle" value="<?php echo $blog_articles_pagetitle; ?>" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap>Article Catergory:</td>
      <td><input type="text" class="form-control" name="blog_category_name" value="<?php echo $blog_category_name; ?>" size="32"></td>
    </tr>
    <td align="right" valign="middle" nowrap>Article Status:</td>
      <td>
      <select class="form-control"  name="blog_articles_level" >
      <option value='Approved' <?php if ($blog_articles_level == 'Approved') {echo "selected='selected'";} ?>>Approved</option>
<option value='Not Approved' <?php if ($blog_articles_level == 'Not Approved') {echo "selected='selected'";} ?>>Not Approved</option>
<option value='Yet to be Administered' <?php if ($blog_articles_level == 'Yet to be Administered') {echo "selected='selected'";} ?>>Yet to be Administered</option>

      </select>
      </td>
    <tr valign="baseline">
      <td nowrap align="right" valign="middle">A Shortdescription of your Article:</td>
      <td><textarea  class="form-control"  name="blog_articles_shortdesc" cols="70" rows="10"><?php echo $blog_articles_shortdesc; ?></textarea>
      </td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right" valign="middle">Article:</td>
      <td><textarea  class="form-control"  name="blog_articles_description" cols="70" rows="50"><?php echo $blog_articles_description; ?></textarea>
      </td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap>&nbsp;</td>
      <td><input type="submit" class="btn btn-default" value="Update record"></td>
    </tr>
  </table>
  <input type="hidden" name="blog_category_id" value="<?php echo $blog_category_id; ?>">
  <input type="hidden" name="blog_articles_id" value="<?php echo $blog_articles_id; ?>">
  <input type="hidden" name="blog_id" value="<?php echo $blog_id; ?>">
  <input type="hidden" name="MM_update" value="form1">
</form>
<!--end-->
</div>
