<?php
if ($this->session){
	//var_dump($admin_details);	
}
foreach ($one_category as $k=>$v){
		$blog_id= $v['blog_id'];
		$blog_category_id = $v['blog_category_id'];
		$blog_category_name = $v['blog_category_name'];
		$blog_category_slug = $v['blog_category_slug'];
}
?>

<form method="post" name="form1" action="<?php echo $base_url; ?>admin/categories/edit/<?php echo $blog_category_id; ?>">
  <table align="center">
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap>Category Name:</td>
      <td><input type="text" class="form-control" name="blog_category_name" value="<?php echo $blog_category_name; ?>" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap>Category Slug:</td>
      <td><input type="text" class="form-control" name="blog_category_slug" value="<?php echo $blog_category_slug; ?>" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap">&nbsp;</td>
      <td><input type="submit" value="Update Record" class="btn btn-default" /></td>
    </tr>
  </table>
  <input type="hidden" name="blog_category_id" value="<?php echo $blog_category_id; ?>">
  <input type="hidden" name="category_update" value="form1">
</form>
<!--end-->
</div>
