<?php
if ($this->session){
	//var_dump($admin_details);	
}
?>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$url = $this->config->item('base_url');
?>

<form action="<?php echo $base_url; ?>admin/categories/create" method="post" name="form1" id="form1">
  <table align="center" class="tablecontent1">
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap">Blog Name:</td>
      <td><select class="form-control"  name="blog_id" >
          <?php foreach ($blog_content as $k=>$v){ ?>
          <option value='<?php echo $v['blog_id']; ?>'><?php echo $v['blog_fname']; ?> <?php echo $v['blog_lname']; ?></option>
          <?php } ?>
        </select></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap">Category Name:</td>
      <td><input type="text" class="form-control" name="blog_category_name" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap">&nbsp;</td>
      <td><input type="submit" value="Insert record" class="btn btn-default" /></td>
    </tr>
  </table>
  <input type="hidden" name="blog_category_id" value="" />
  <input type="hidden" name="category_creation" value="" />
  <input type="hidden" name="MM_insert" value="form1" />
</form>
</div>
