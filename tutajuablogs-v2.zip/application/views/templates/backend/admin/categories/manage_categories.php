<?php

?>
<div align="center"><strong><?php echo $success; ?></strong></div> 

<div class="table-responsive">
  <table class="table table-striped">
    <tr>
      <td><div align="center" style="font-weight: bold">ID</div></td>
      <td><div align="center" style="font-weight: bold">Author</div></td>
      <td><div align="center" style="font-weight: bold">Category Name</div></td>
      <td><div align="center" style="font-weight: bold">Published Date</div></td>
      <td colspan="2"><div align="center" style="font-weight: bold">Actions</div></td>
    </tr>
    <?php foreach ($all_categories as $row_Categories){ ?>
    <tr >
      <td><a href="#"><?php echo $row_Categories['blog_category_id']; ?></a></td>
      <td><a href="#"><?php echo $row_Categories['blog_fname']; ?> <?php echo $row_Categories['blog_lname']; ?></a></td>
      <td><a href="#"><?php echo $row_Categories['blog_category_name']; ?></a></td>
      <td><div class="btn btn-default btn-xs"><span style="font-weight: bold"><a href="<?php echo $base_url; ?>admin/categories/edit/<?php echo $row_Categories['blog_category_id']; ?>">Edit</a></span></div></td>
      <td><div class="btn btn-default btn-xs"><span style="font-weight: bold"><a href="<?php echo $base_url; ?>admin/categories/delete/<?php echo $row_Categories['blog_category_id']; ?>/" onclick="return confirm('Are you sure you want to delete?')">Delete</a></span></div></td>
    </tr>
    <?php }  ?>
  </table>
</div>
</div>
