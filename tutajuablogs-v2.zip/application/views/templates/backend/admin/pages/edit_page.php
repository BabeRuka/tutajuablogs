<?php
if ($this->session){
	//var_dump($admin_details);	
}
foreach ($page_details as $row){
	$blog_content_id = $row['blog_content_id'];
	$blog_id = $row['blog_id'];
	$blog_content_description = $row['blog_content_description'];
	$blog_content_page = $row['blog_content_page'];
	$blog_content_pagetitle = $row['blog_content_pagetitle'];
	$blog_content_date = $row['blog_content_date'];
	$blog_content_hits = $row['blog_content_hits'];
}
?>


<form method="post" name="form1" action="<?php echo $base_url; ?>admin/pages/edit">
  <table align="center">
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap>Title:</td>
      <td><input type="text" class="form-control" name="blog_content_pagetitle" value="<?php echo $blog_content_pagetitle; ?>" size="32"></td>
    </tr>

    <tr valign="baseline">
      <td nowrap align="right" valign="middle">Details:</td>
      <td><textarea  class="form-control"  name="blog_content_description" cols="70" rows="50"><?php echo $blog_content_description; ?></textarea>
      </td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap>&nbsp;</td>
      <td><input type="submit" class="btn btn-default" value="Update record"></td>
    </tr>
  </table>
  <input type="hidden" name="blog_content_id" value="<?php echo $blog_content_id; ?>">
  <input type="hidden" name="blog_id" value="<?php echo $blog_id; ?>">
  <input type="hidden" name="page_update" value="form1">
</form>
<!--end-->
</div>
