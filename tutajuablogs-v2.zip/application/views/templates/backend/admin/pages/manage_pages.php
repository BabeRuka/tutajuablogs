<?php

?>
<div align="center"><strong><?php echo $success; ?></strong></div> 


<div class="table-responsive">
  <table class="table table-striped">
  <tr>
    <td><div align="center" style="font-weight: bold">ID</div></td>
    <td><div align="center" style="font-weight: bold">Title</div></td>
    <td><div align="center" style="font-weight: bold">Views</div></td>
    <td><div align="center" style="font-weight: bold">Published Date</div></td>
    <td colspan="2"><div align="center" style="font-weight: bold">Actions</div></td>
  </tr>
  <?php foreach ($page_details as $row){ ?>
  <tr >
    <td><a href="#"><?php echo $row['blog_content_id']; ?></a></td>
    <td><a href="#"><?php echo $row['blog_content_pagetitle']; ?></a></td>
    <td><a href="#"><?php echo $row['blog_content_hits']; ?></a></td>
    <td><a href="#"><?php echo $row['blog_content_date']; ?></a></td>
    <td><div class="btn btn-default btn-xs"><span style="font-weight: bold">
    <a href="<?php echo $base_url; ?>admin/pages/edit/<?php echo $row['blog_content_id']; ?>/<?php echo $row['blog_id']; ?>">Edit</a></span></div>
    </td>
    <td>
    <div class="btn btn-default btn-xs"><span style="font-weight: bold"><a href="<?php echo $base_url; ?>admin/pages/delete/<?php echo $row['blog_content_id']; ?>/<?php echo $row['blog_id']; ?>"onclick="return confirm('Are you sure you want to delete?')">Delete</a></span>
    </div>
    </td>
  </tr>
  <?php }  ?>
</table>
</div>
