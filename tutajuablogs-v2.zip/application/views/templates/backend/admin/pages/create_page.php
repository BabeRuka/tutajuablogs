<?php
if ($this->session){
	//var_dump($admin_details);	
}
?>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$url = $this->config->item('base_url');
?>

<form action="<?php echo $base_url; ?>admin/pages/create" method="post" name="form1" id="form1">
  <table align="center" class="tablecontent1">
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap">Page Name:</td>
      <td>
      <select name="blog_id" class="form-control"   >
		  <?php foreach ($blog_content as $k=>$v){ ?>
                    <option value='<?php echo $v['blog_id']; ?>'><?php echo $v['blog_fname']; ?> <?php echo $v['blog_lname']; ?></option>
          <?php } ?>
      </select>      
      </td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap">Title:</td>
      <td><input type="text" class="form-control" name="blog_content_pagetitle" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right" valign="middle">Page Details:</td>
      <td><textarea  class="form-control"  name="blog_content_description" class="form-control" cols="70" rows="70"></textarea>      </td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap">&nbsp;</td>
      <td><input type="submit" value="Insert record" class="btn btn-default" /></td>
    </tr>
  </table>
  <input type="hidden" name="blog_content_id" value="" />
  <input type="hidden" name="blog_content_date" value="" />
  <input type="hidden" name="page_insert" value="form1" />
</form>

</div>
