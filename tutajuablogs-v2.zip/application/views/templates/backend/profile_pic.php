<?php if ($success){ ?>
<div><strong><?php echo $success;?></strong></div>
<?php } ?>
<?php echo $error;?>
<div>
<form action="<?php echo $this->config->item('base_url'); ?>profile/do_upload" method="post" enctype="multipart/form-data">
    <div>Select a profile Picture to upload:</div>
    <div><input type="file" name="profile_pic" id="profile_pic"></div>
    <div>
    <input type="hidden" value="<?php echo $this->uri->segment(3); ?>" name="blog_id">
    <input type="submit" value="Upload Profile Picture" class="btn btn-default" name="submit"></div>
</form>
</div>
<!--end--></div>