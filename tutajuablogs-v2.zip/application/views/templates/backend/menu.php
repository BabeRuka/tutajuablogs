
<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      <a class="navbar-brand" href="#">Tutajua Blogs Admin</a> </div>
    <div id="navbar" class="navbar-collapse collapse">
      <ul class="nav navbar-nav navbar-right">
        <li><a  href="<?php echo $base_url; ?>">Blogs Home</a></li>
        <li><a  href="<?php echo $base_url; ?>admin/index">Admin Home</a></li>
        <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Blogs<span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <?php if ($this->session->userdata('blog_catergory') == 'Super Administrator'){ ?>
            <li><a href="<?php echo $base_url; ?>admin/blogs/create"> Create Blog </a></li>
            <?php } ?>
            <li><a href="<?php echo $base_url; ?>admin/index"> Manage Blogs </a></li>
          </ul>
        </li>
        <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Pages<span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="<?php echo $base_url; ?>admin/pages/create"> Create Pages</a></li>
            <li><a href="<?php echo $base_url; ?>admin/pages"> Manage Pages </a></li>
          </ul>
        </li>
        <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Categories<span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="<?php echo $base_url; ?>admin/categories/create"> Create Category</a></li>
            <li><a href="<?php echo $base_url; ?>admin/categories"> Manage Category </a></li>
          </ul>
        </li>
        <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Articles<span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="<?php echo $base_url; ?>admin/articles/create"> Create Article</a></li>
            <li><a href="<?php echo $base_url; ?>admin/articles"> Manage Articles </a></li>
          </ul>
        </li>
        <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Comments<span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="<?php echo $base_url; ?>admin/comments"> Manage Comments </a></li>
          </ul>
        </li>
        <li><a href="<?php echo $base_url; ?>logout/index" id="MenuBarItemSubmenu">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
<div style="margin-top:3%">
<div class="container-fluid">
<div class="row">
<div class="col-sm-2 sidebar well">
  <ul class="nav nav-sidebar">
    <li><a class="MenuBarItemSubmenu" href="<?php echo $base_url; ?>">Blogs Home</a></li>
    <li><a class="MenuBarItemSubmenu" href="<?php echo $base_url; ?>admin/index">Admin Home</a></li>
    <li><a href="#" class="MenuBarItemSubmenu">Pages </a>
      <ul>
        <li><a href="<?php echo $base_url; ?>admin/pages/create"> Create Pages</a></li>
        <li><a href="<?php echo $base_url; ?>admin/pages"> Manage Pages </a></li>
      </ul>
    </li>
    <li><a href="#" class="MenuBarItemSubmenu">Categories </a>
      <ul>
        <li><a href="<?php echo $base_url; ?>admin/categories/create"> Create Category</a></li>
        <li><a href="<?php echo $base_url; ?>admin/categories"> Manage Category </a></li>
      </ul>
    </li>
    <li><a href="#" class="MenuBarItemSubmenu">Articles </a>
      <ul>
        <li><a href="<?php echo $base_url; ?>admin/articles/create"> Create Article</a></li>
        <li><a href="<?php echo $base_url; ?>admin/articles"> Manage Articles </a></li>
      </ul>
    </li>
    <li><a href="#" class="MenuBarItemSubmenu">Comments </a>
      <ul>
        <li><a href="<?php echo $base_url; ?>admin/comments"> Manage Comments </a></li>
      </ul>
    </li>
    <li><a href="<?php echo $base_url; ?>logout/index" id="MenuBarItemSubmenu">Logout</a></li>
  </ul>
</div>
<div class="col-sm-9 main">
<h1 class="page-header"> Welcome <?php echo $_SESSION['blog_fname']; ?> <?php echo $_SESSION['blog_lname']; ?></h1>
