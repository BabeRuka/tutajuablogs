<div align="center"><strong><?php echo $success; ?></strong></div> 
<div class="table-responsive">
  <table class="table table-striped">
    <tr class="trevebheadlibe">
      <td><div align="center" style="font-weight: bold">
          <div align="center">ID</div>
        </div></td>
      <td><div align="center" style="font-weight: bold">
          <div align="center">First Name</div>
        </div></td>
      <td><div align="center" style="font-weight: bold">
          <div align="center">Last Name</div>
        </div></td>
      <td><div align="center" style="font-weight: bold">
          <div align="center">Email</div>
        </div></td>
      <td><div align="center" style="font-weight: bold">
          <div align="center">Level</div>
        </div></td>
      <td><div align="center" style="font-weight: bold">
          <div align="center">Logins</div>
        </div></td>
      <td><div align="center" style="font-weight: bold">
          <div align="center">Last Login</div>
        </div></td>
      <td><div align="center" style="font-weight: bold">
          <div align="center">Category</div>
        </div></td>
      <td><div align="center" style="font-weight: bold">
          <div align="center">Profile Pic</div>
        </div></td>
      <td><div class="" style="font-weight: bold">
          <div align="center">Admin Actions</div>
        </div></td>
    </tr>
    <?php foreach($admin_details as $row_Blog) { ?>
    <tr class="trodd">
      <td><?php echo $row_Blog['blog_id']; ?></td>
      <td><?php echo $row_Blog['blog_fname']; ?></td>
      <td><?php echo $row_Blog['blog_lname']; ?></td>
      <td><?php echo $row_Blog['blog_email']; ?></td>
      <td><?php echo $row_Blog['blog_level']; ?></td>
      <td><?php echo $row_Blog['blog_logins']; ?></td>
      <td><?php echo $row_Blog['blog_lastlogin']; ?></td>
      <td><?php echo $row_Blog['blog_catergory']; ?></td>
      <td align="center" valign="middle"><?php if(empty($row_Blog['blog_profile_pic'])){ ?>
        <div class="btn btn-default btn-xs"><a href="<?php echo $this->config->item('base_url'); ?>profile/index/<?php echo $row_Blog['blog_id']; ?>">Upload Profile Pic</a></div>
        <?php }else{?>
        <a href="<?php echo $this->config->item('base_url'); ?>profile/index/<?php echo $row_Blog['blog_id']; ?>"><img src="<?php echo $this->config->item('base_url'); ?>assets/images/<?php echo $row_Blog['blog_profile_pic']; ?>" alt="Upload a Profile Picture" title="Upload a Profile Picture" width="50" height="50" /></a>
        <?php } ?></td>
      <td><?php if ($this->session->userdata('blog_catergory') == 'Super Administrator') {	?>
        <div class="btn btn-default btn-xs"><a href="<?php echo $base_url; ?>admin/blogs/manage/<?php echo $row_Blog['blog_id']; ?>">Manage <?php echo $row_Blog['blog_fname']; ?>'s Records</a></div>
        <?php } ?>
        <div class="btn btn-default btn-xs"><a href="<?php echo $base_url; ?>admin/blogs/edit/<?php echo $row_Blog['blog_id']; ?>">Edit <?php echo $row_Blog['blog_fname']; ?>'s Records</a></div>
        <div class="btn btn-default btn-xs"><a href="<?php echo $base_url; ?>admin/password/<?php echo $row_Blog['blog_id']; ?>">Change <?php echo $row_Blog['blog_fname']; ?>'s Password</a></div>
        <?php if ($this->session->userdata('blog_catergory') == 'Super Administrator'){ ?>
      <div class="btn btn-default btn-xs"><a href="<?php echo $base_url; ?>admin/blogs/delete/<?php echo $row_Blog['blog_id']; ?>" onclick="return confirm('Are you sure you want to delete?')">Delete <?php echo $row_Blog['blog_fname']; ?>'s Records</a></div></td>
        <?php } ?>
    </tr>
    <?php } ?>
  </table>
  <!--end--></div>
  </div>
