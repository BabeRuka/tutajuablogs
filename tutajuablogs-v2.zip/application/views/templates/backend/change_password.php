<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$url = $this->config->item('base_url');
?>
<div class="container">
<div class="row">
  <div class="col-md-12">
  <div align="center"><strong><?php echo $success; ?></strong></div>
  <?php echo form_open(''.$url.'admin/password/change'); ?>
  <div>
    <h5>Password</h5>
    <?php echo form_error('password'); ?>
    <input type="password" name="password"  class="form-control"  value="<?php echo set_value('password'); ?>" size="50" />
  </div>
  <div>
    <h5>Repeat Password</h5>
    <?php //echo $email_error; ?>
    <?php echo form_error('repeat_password'); ?>
    <input type="password" name="repeat_password"  class="form-control"  value="<?php echo set_value('password'); ?>" size="50" />
    <input type="hidden" name="blog_id" value="<?php echo $this->session->userdata['blog_id'];  ?>" size="50" />
  </div>
  <div>
    <input type="submit" value="Submit" class="btn btn-default" />
  </div>
  </form>
</div>
</div>
</div>