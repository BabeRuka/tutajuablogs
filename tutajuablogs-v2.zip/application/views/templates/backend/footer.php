<!--end container--> </div>
<!--end row--> </div>

<div class="row">
  <div class="text-center col-md-6 col-md-offset-3">
    <p>Copyright &copy; TutajuBlogs <?php echo date('Y'); ?>&middot; All Rights Reserved &middot; </p>
  </div>
</div>
<hr>
</div>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="<?php echo $this->config->item('base_url'); ?>assets/js/jquery-1.11.3.min.js"></script> 

<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="<?php echo $this->config->item('base_url'); ?>assets/js/bootstrap.js"></script>
</body></html>