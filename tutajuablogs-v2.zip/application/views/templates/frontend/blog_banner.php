<?php
if (isset( $blog_id ) ) {
	$search_id = '/'.$blog_id; 
 }else{
	$search_id = ''; 
 }
 ?>
<body>
<div class="container">
<div class="header">
  <div class="fltrt">
    <div class="search-wrapper">
      <form action="<?php echo $url; ?>search/index<?php echo $search_id ; ?>" method="post">
        <table align="right">
          <tr>
            <td><input name="description" type="text" class="search" id="description" required  /></td>
            <td></td>
            <td><input type="submit" class="search-button" value="Search"></td>
          </tr>
          <td><h1 align="right">
                <img src="images/<?php echo $row['blog_id']; ?>.jpg"  width="113" height="150" class="rightpic"/>
              </h1></td>
        </table>
      </form>
      <!-- end .search-wrapper--></div>
    <!-- end .fltrt --></div>
  <div class="fltlft">
    <div class="search-wrapper-lft">
      <h1 align="right"><img src="<?php echo $this->config->item('base_url'); ?>assets/images/logo.png" alt="Logo"></h1>
    </div>
  </div>
  <br class="clearfloat" />
  <!-- end .header --></div>
<div class="menu">
  <ul id="MenuBar1" class="MenuBarHorizontal">
    <li><a href="index.php">Blogs Home</a></li>
    <li><a href="authors.php">Blog Authors</a></li>
    <li><a href="archives.php">Blog Archives</a></li>
    <li><a href="blog_articles.php">Blog Articles</a></li>
    <li><a href="blog_catergories.php">Blog Catergories</a></li>
    <li><a href="register_blog.php">Register a Blog</a></li>
    <li><a href="admin/login.php">Blog Login</a></li>
  </ul>
  <!-- end .menu --></div>
<div class="content">
