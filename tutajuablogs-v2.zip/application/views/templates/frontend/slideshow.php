<?php
$url = $this->config->item('base_url');
if ( $this->unit->run($this->uri->segment(3), 'is_int') ){ 
	$blog_id =  '/index/'.$this->uri->segment(3); 
}else{
	$blog_id =  '/index/all'; 
}
if (isset( $blog_id ) ) {
	$search_id = '/'.$blog_id; 
 }else{
	$search_id = ''; 
 }
?>
<body>
<div class="container">
<div class="header">
  <div class="fltlft">
    <div class="search-wrapper">
      <h1 align="right"><img src="<?php echo $this->config->item('base_url'); ?>assets/images/logo.png" alt="Logo"></h1>
    </div>
  </div>
  <div class="fltrt">
    <div class="search-wrapper">
     
      <form action="<?php echo $url; ?>search/index<?php echo $search_id ; ?>" method="post">
       <table align="left">
            <tr>
              <td align="right"><input name="description" type="text"  class="searchfld" id="description"  required="required"  /></td>
              <td><input type="submit" class="search-button" value="Search"></td>
              <td></td>
            </tr>
          </table>
        </form>

     
     
     
      <!-- end .search-wrapper--></div>
    <!-- end .fltrt --></div>
  <br class="clearfloat" />
  <!-- end .header --></div>
<div class="menu">
  <ul id="MenuBar1" class="MenuBarHorizontal">
    <li><a href="<?php echo $this->config->item('base_url'); ?>">Blogs Home</a></li>
    <li> <a href="<?php echo $this->config->item('base_url'); ?>all_archives<?php echo $blog_id;?>">Archives</a>
      <ul>
        <li><a href="<?php echo $this->config->item('base_url'); ?>all_archives<?php echo $blog_id;?>">Archives</a></li>
        <li><a href="<?php echo $this->config->item('base_url'); ?>categories<?php echo $blog_id;?>all">Blog Catergories</a></li>
      </ul>
    </li>
    <li><a href="register_blog.php">Register</a></li>
    <li><a href="login.php">Login</a></li>
  </ul>
  <!-- end .menu --></div>
<div class="content">
