
<div class="col-sm-4 well">
  <?php
defined('BASEPATH') OR exit('No direct script access allowed');
$url = $this->config->item('base_url');
?>
  <h3>Arcives</h3>
  <ul class="list-group">
    <?php foreach ($archived_articles as $k=>$v) {;  ?>
    <?php
		if ($v['MonthPublished'] == 1 ) { $month = 'January';  }
		else if ($v['MonthPublished'] == 2 ) { $month = 'February';  }
		else if ($v['MonthPublished'] == 3 ) { $month = 'March';  }
		else if ($v['MonthPublished'] == 4 ) { $month = 'April';  }
		else if ($v['MonthPublished'] == 5 ) { $month = 'May';  }
		else if ($v['MonthPublished'] == 6 ) { $month = 'June';  }
		else if ($v['MonthPublished'] == 7 ) { $month = 'July';  }
		else if ($v['MonthPublished'] == 8 ) { $month = 'August';  }
		else if ($v['MonthPublished'] == 9 ) { $month = 'September';  }
		else if ($v['MonthPublished'] == 10 ) { $month = 'October';  }
		else if ($v['MonthPublished'] == 11 ) { $month = 'November';  }
		else if ($v['MonthPublished'] == 12 ) { $month = 'December';  }
		?>
    <li class="list-group-item"><a href="<?php echo $url; echo 'all_archives/article/'; echo $v['YearPublished']; ?>/<?php echo $v['MonthPublished']; ?>" alt="<?php echo $v['ArticlesPublished']; ?> Articles Published for the month of <?php echo $v['MonthPublished']; ?>" title="<?php echo $v['ArticlesPublished']; ?> Articles Published for the month of <?php echo $month; ?>" ><?php echo $v['FullDate']; ?><span class="badge pull-right"><?php echo $v['ArticlesPublished']; ?> Articles</span></a></li>
    <?php } ?>
  </ul>
  
  <!-- categories -->
  
  <h3>Categories</h3>
  <ul class="list-group">
    <?php 
	  foreach ($grouped_categories as $k=>$v) {; 
		 if ( $this->uri->segment(3) ) {
			$link = $url.'categories/category/'.$this->uri->segment(3).'/'.$v['blog_category_slug']; 
		}else{
			$blog_id=$this->uri->segment(3,0);
			$link = $url.'categories/category/'.$blog_id.'/'.$v['blog_category_slug']; 
		}
	    //echo '<h1>'.$this->uri->segment(3).' A PHP Error was encountered</h1>'; 
	   ?>
    <li class="list-group-item"> <a href="<?php echo $link; ?>" alt="<?php echo $v['TotalArticles']; ?> Articles in the <?php echo $v['blog_category_name']; ?> Categories" title="<?php echo $v['TotalArticles']; ?> Articles in the <?php echo $v['blog_category_name']; ?> Categories" ><?php echo $v['blog_category_name']; ?> <span class="badge pull-right"><?php echo $v['TotalArticles']; ?> Articles</span></a></li>
    <?php } ?>
  </ul>
  
  <!-- end categories --> 
</div>
</div>
</div>
</div

