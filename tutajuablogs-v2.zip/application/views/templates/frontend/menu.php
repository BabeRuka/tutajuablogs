<?php
 $url = $this->config->item('base_url');
 if (isset( $blog_id ) ) {
	$search_id = '/'.$blog_id; 
 }else{
	$search_id = ''; 
 }
?>
<body>
<?php if (!empty( $_SESSION['blog_id'])) { ?>  
<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      <a class="navbar-brand" href="#"> Welcome <?php echo $_SESSION['blog_fname']; ?> <?php echo $_SESSION['blog_lname']; ?></a> </div>
    <div id="navbar" class="navbar-collapse collapse">
      <ul class="nav navbar-nav navbar-right">
        <li><a  href="<?php echo $url; ?>admin/index">Admin Home</a></li>
        <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Blogs<span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <?php if ($_SESSION['blog_catergory'] == 'Super Administrator'){ ?>
            <li><a href="<?php echo $url; ?>admin/blogs/create"> Create Blog </a></li>
            <?php } ?>
            <li><a href="<?php echo $url; ?>admin/index"> Manage Blogs </a></li>
          </ul>
        </li>
        <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Pages<span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="<?php echo $url; ?>admin/pages/create"> Create Pages</a></li>
            <li><a href="<?php echo $url; ?>admin/pages"> Manage Pages </a></li>
          </ul>
        </li>
        <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Categories<span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="<?php echo $url; ?>admin/categories/create"> Create Category</a></li>
            <li><a href="<?php echo $url; ?>admin/categories"> Manage Category </a></li>
          </ul>
        </li>
        <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Articles<span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="<?php echo $url; ?>admin/articles/create"> Create Article</a></li>
            <li><a href="<?php echo $url; ?>admin/articles"> Manage Articles </a></li>
          </ul>
        </li>
        <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Comments<span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="<?php echo $url; ?>admin/comments"> Manage Comments </a></li>
          </ul>
        </li>
        <li><a href="<?php echo $url; ?>logout/index" id="MenuBarItemSubmenu">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
<?php } ?>
<div class="container" <?php if (!empty( $_SESSION['blog_id'])) { ?> style="margin-top:2%" <?php } ?> >
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="top-logo"><img src="<?php echo $this->config->item('base_url'); ?>assets/images/logo.png" alt="Logo" class="img-responsive">
    <h1><?php echo $title ; ?></h1></div>
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#defaultNavbar1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
    </div>
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="defaultNavbar1">
      <ul class="nav navbar-nav">
        <li><a href="<?php echo $url; ?>">Blogs Home</a></li>
        <li><a href="<?php echo $url; ?>blog/index/<?php echo $blog_id; ?>">Homepage</a></li>
        <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Archives<span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="<?php echo $url; ?>archives/index/<?php echo $blog_id; ?>">Archives</a></li>
            <li><a href="<?php echo $this->config->item('base_url'); ?>categories/index/<?php echo $blog_id; ?>">My Catergories</a></li>
          </ul>
        </li>
        <?php if(count($my_blog_content) > 0) { ?>
        <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Pages<span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <?php foreach ($my_blog_content as $k=>$v){ ?>
            <?php echo '<li><a href="'.$this->config->item('base_url').'page/index/'. $v['blog_id'].'/'. $v['blog_content_id'].'">'. ''.'
	  '.$v['blog_content_pagetitle'].'</a></li>';  ?>
            <?php }  ?>
          </ul>
        </li>
        <?php }  ?>
        <li><a href="<?php echo $this->config->item('base_url'); ?>login/index">Login</a></li>
      </ul>
      <form action="<?php echo $url; ?>search/index" method="post" class="navbar-form navbar-right" role="search">
        <div class="form-group">
          <input name="description" type="text"  class="form-control" id="description"  required="required"   />
        </div>
        <input type="submit" class="btn btn-default" value="Search">
      </form>
    </div>
    <!-- /.navbar-collapse --> 
  </div>
  <!-- /.container-fluid --> 
</nav>
<div class="row">
