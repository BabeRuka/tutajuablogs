  <div class="catergories">
    <div class="blogcontent">
    <!--ooslide-->
    
	
    <!--start noobslide-->

<div class="mask1">
  <div id="box8">
    <?php do { ?>
      <?php echo '<div><h3>'. $row_Archives['blog_pagetitle'].' | '. $row_Archives['blog_articles_pagetitle'].' | <strong>Article Posted on '. $row_Archives['blog_article_date'].':</strong></h3>
      <p><a href="out.php?blog_articles_id='. $row_Archives['blog_articles_id'].'&blog_id='. $row_Archives['blog_id'].'">'. $row_Archives['blog_articles_shortdesc'].' </p></a><br>
<div id="line"></div><br></div>';
?>
      <?php } while ($row_Archives = mysql_fetch_assoc($Archives)); ?>
    
    <!--end mask1--></div>
  <!--end box8--></div>
<div class="slide-wrapper">
  <p class="buttons"> <span id="playback8" class="slide">&laquo;</span> <span id="stop8" class="slide">&bull;</span> <span id="play8" class="slide">&raquo;</span> </p>
  <!--end slide-wrappere--></div>

<!--end noobslide--> 
    
    
    
    <!--ed-->
    <!--end blogcontent--></div>
    <!--end catergories--></div>
    