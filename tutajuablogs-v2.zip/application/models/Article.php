<?php 
class Article extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->library('session');
				$this->load->library('unit_test');
        }
		function getBlogID() {

			if ($this->uri->segment(3)){
				$blog = $this->uri->segment(3);
			}
			
			return $blog;
		}

		function getArticleID() {

			if ($this->uri->segment(4)){
				$blog = $this->uri->segment(4);
			}
			
			return $blog;
		}
		function get_article(){
			
			$article_id = $this->getArticleID();
			$blog_id = $this->getBlogID();
	
			$query = $this->db->query(" SELECT * FROM tutajua_blogs, tutajua_blog_articles 
			WHERE tutajua_blogs.blog_id = '".$blog_id."'  
			AND tutajua_blog_articles.blog_articles_id = '".$article_id."' " );
			return $query->result_array();
		}
		
		function get_all_articles(){
			
			$query = $this->db->query(" SELECT
			tutajua_blog_articles.blog_articles_id,
			tutajua_blog_articles.blog_content_id,
			tutajua_blog_articles.blog_articles_catergory,
			tutajua_blog_articles.blog_articles_quote,
			tutajua_blog_articles.blog_articles_shortdesc,
			tutajua_blog_articles.blog_articles_description,
			tutajua_blog_articles.blog_articles_page,
			tutajua_blog_articles.blog_articles_pagetitle,
			tutajua_blog_articles.blog_article_date,
			tutajua_blog_articles.blog_articles_image,
			tutajua_blog_articles.blog_article_hits,
			tutajua_blog_articles.blog_articles_level,
			tutajua_blogs.blog_fname,
			tutajua_blogs.blog_lname,
			tutajua_blogs.blog_id
			FROM
			tutajua_blogs
			INNER JOIN tutajua_blog_articles ON tutajua_blog_articles.blog_id = tutajua_blogs.blog_id
			ORDER BY tutajua_blog_articles.blog_articles_id DESC " );
			return $query->result_array();
		}

		function get_my_articles($blog_id){
			
			$article_id = $this->getArticleID();
			$blog_id = $this->getBlogID();
	
			$query = $this->db->query(" SELECT
			tutajua_blog_articles.blog_articles_id,
			tutajua_blog_articles.blog_content_id,
			tutajua_blog_articles.blog_articles_catergory,
			tutajua_blog_articles.blog_articles_quote,
			tutajua_blog_articles.blog_articles_shortdesc,
			tutajua_blog_articles.blog_articles_description,
			tutajua_blog_articles.blog_articles_page,
			tutajua_blog_articles.blog_articles_pagetitle,
			tutajua_blog_articles.blog_article_date,
			tutajua_blog_articles.blog_articles_image,
			tutajua_blog_articles.blog_article_hits,
			tutajua_blog_articles.blog_articles_level,
			tutajua_blogs.blog_fname,
			tutajua_blogs.blog_lname,
			tutajua_blogs.blog_id
			FROM
			tutajua_blogs
			INNER JOIN tutajua_blog_articles ON tutajua_blog_articles.blog_id = tutajua_blogs.blog_id 
			WHERE tutajua_blogs.blog_id = '".$blog_id."'  
			ORDER BY tutajua_blog_articles.blog_articles_id DESC " );
			return $query->result_array();
		}
		function get_blog_id($article_id){
			
			$query = $this->db->query(" SELECT tutajua_blog_articles.blog_id
			FROM `tutajua_blog_articles` 
			WHERE tutajua_blog_articles.blog_articles_id = '".$article_id."' " );
			$row = $query->row();
			if($query){
				$blog_id = $row->blog_id; 
			}else{
				$blog_id = ''; 
			}
			return $blog_id;
		}	
		
		function get_article_title($result){
			
			$article_id = $this->getArticleID();
			$blog_id = $this->getBlogID();
	
			$query = $this->db->query(" SELECT * FROM tutajua_blogs, tutajua_blog_articles 
			WHERE tutajua_blogs.blog_id = '".$blog_id."'  
			AND tutajua_blog_articles.blog_articles_id = '".$article_id."' " );
			$row = $query->row();
			if($result = 'blog_title'){
				$title = $row->blog_pagetitle; 
			}else{
				$aarticle_title = $row->blog_articles_pagetitle; 
			}
			return $title;
		}	
}