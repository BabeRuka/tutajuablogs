<?php 
class Detailed_search extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->library('session');
				$this->load->library('unit_test');
        }
		function keyword(){
			return $this->db->escape_like_str($this->input->post('description'));	
		}
				
		function detailed_search_blogs() {
			
			$description = $this->keyword();	 
			
        	$query = $this->db->query(" 
			SELECT * FROM tutajua_blogs 
			WHERE CAST( `tutajua_blogs`.`blog_description` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%'
			OR CAST( `tutajua_blogs`.`blog_page` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `tutajua_blogs`.`blog_pagetitle` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `tutajua_blogs`.`blog_fname` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `tutajua_blogs`.`blog_lname` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `tutajua_blogs`.`blog_email` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			");
			
			return $query->result_array();
		}
		
		function detailed_search_articles() {
			$description = $this->keyword();	 
			
        	$query = $this->db->query(" 
			SELECT * FROM tutajua_blogs
			INNER JOIN tutajua_blog_articles ON tutajua_blog_articles.blog_id = tutajua_blogs.blog_id 
			WHERE CAST( `tutajua_blogs`.`blog_description` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%'
			OR CAST( `tutajua_blogs`.`blog_page` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `tutajua_blogs`.`blog_pagetitle` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `tutajua_blogs`.`blog_fname` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `tutajua_blogs`.`blog_lname` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `tutajua_blogs`.`blog_email` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `tutajua_blog_articles`.`blog_articles_catergory` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `tutajua_blog_articles`.`blog_articles_quote` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `tutajua_blog_articles`.`blog_articles_shortdesc` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `tutajua_blog_articles`.`blog_articles_description` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `tutajua_blog_articles`.`blog_articles_page` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `tutajua_blog_articles`.`blog_articles_pagetitle` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `tutajua_blog_articles`.`blog_articles_image` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%'
			");
			
			return $query->result_array();
		}
		
		function detailed_search_categories() {

			if ($this->uri->segment(4)){
				$page = $this->uri->segment(4);
			}else{
				$page = 1;
			}
			$blog_id=$this->getBlogID();
			$limit = $this->getLimit();
			$startpoint = ($page * $limit) - $limit;
			$limitQ = 'LIMIT '.$startpoint.', '.$limit.'';
        	$query = $this->db->query(" SELECT * FROM tutajua_blogs, tutajua_blog_articles 
			WHERE tutajua_blogs.blog_id = tutajua_blog_articles.blog_id 
			AND tutajua_blogs.blog_id = '".$blog_id."' 
			AND tutajua_blogs.blog_level = 'Approved' 
			ORDER BY tutajua_blog_articles.blog_articles_id DESC
			-- ".$limitQ." ");
			
			return $query->result_array();
		}
						
		
		function detailed_search_pages() {

			if ($this->uri->segment(4)){
				$page = $this->uri->segment(4);
			}else{
				$page = 1;
			}
			$blog_id=$this->getBlogID();
			$limit = $this->getLimit();
			$startpoint = ($page * $limit) - $limit;
			$limitQ = 'LIMIT '.$startpoint.', '.$limit.'';
        	$query = $this->db->query(" SELECT * FROM tutajua_blogs, tutajua_blog_articles 
			WHERE tutajua_blogs.blog_id = tutajua_blog_articles.blog_id 
			AND tutajua_blogs.blog_id = '".$blog_id."' 
			AND tutajua_blogs.blog_level = 'Approved' 
			ORDER BY tutajua_blog_articles.blog_articles_id DESC
			-- ".$limitQ." ");
			
			return $query->result_array();
		}
	
	}