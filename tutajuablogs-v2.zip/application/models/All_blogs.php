<?php 
class All_blogs extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->library('session');
				$this->load->library('unit_test');
        }
		function getAllBlogContentRows() {
		
		$query = $this->db->query(" SELECT * FROM `tutajua_blogs` 
		WHERE `blog_level`='Approved' 
		ORDER BY blog_id ASC ");
		$rowcount = $query->num_rows();	
		
		return $rowcount;
			
		}		
		function all_blog_content() {

        	$query = $this->db->query(" SELECT * FROM `tutajua_blogs` 
			WHERE `blog_level`='Approved' 
			ORDER BY blog_id ASC ");
			
			return $query->result_array();
		}
		
		function all_blog_articles(){

			$query = $this->db->query( " SELECT * FROM tutajua_blogs, tutajua_blog_articles 
			WHERE tutajua_blogs.blog_id = tutajua_blog_articles.blog_id 
			AND tutajua_blogs.blog_level = 'Approved' 
			AND blog_articles_level = 'Approved' 
			ORDER BY tutajua_blog_articles.blog_articles_id DESC " ) ;
			
			return $query->result_array();
		}
		function my_blog_title($blog_id) {
			$query = $this->db->query(" SELECT blog_pagetitle FROM tutajua_blogs WHERE blog_id = '".$blog_id."' ");
			$row = $query->row_array();
			
			return $row['blog_pagetitle'];
		
		}
		function my_blog_details($blog_id) {
			$query = $this->db->query(" SELECT * FROM tutajua_blogs WHERE blog_id = '".$blog_id."' ");
			
			return $query->result_array();
		
		}
		
		function getCurrentCount() {
		
			$limit = $this->getLimit();
			if ($this->uri->segment(4)){
				$page = $this->uri->segment(4);
				$start = $page * $limit;
				$startCount = $start - $limit;
			}else{
				$startCount = 0;
			}
			
			return $startCount;
			
		}
		function getLimit() {
			$limit = 25;
			return $limit;
			
		}		
		function getAllAssessementlimit() {
		
			if ($this->uri->segment(4)){
				$page = $this->uri->segment(4);
			}else{
				$page = 1;
			}
			$limit = $this->getQaAssessementlimit();
			$limitQ = $page * $limit;
			return $limitQ;
			
		}
		function getAllRecordCount() {
		$limit = $this->getLimit();
		if ($this->uri->segment(4)){
				$page = $this->uri->segment(4);
				$current_count = $page * $limit;
			}else{
				$page = '1';
				$current_count = $limit;
			}
			
			$startpoint = ($page * $limit) - $limit;	
			$recordCount=min($startpoint + $limit, $this->getAllBlogContentRows());
			
			return $current_count; 
		}
		
			
		
}