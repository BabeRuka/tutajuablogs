<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Authentication extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->library('session');
				$this->load->library('unit_test');
        }

    function is_loggedin($user_session) {
		if(empty($user_session)){
			redirect($this->config->item('base_url').'login/index');
			return false;
		}
	}
	
}

?>