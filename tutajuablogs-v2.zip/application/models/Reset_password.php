<?php 
class Reset_password extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->helper('string');
				$this->load->library('session');

        }
		function change(){
			
			$blog_passwordkey =  '';
			$date =  date('Y-m-d H:m:s');
			$password = md5($this->input->post('password'));
		
			if ($password != '') {
				$blog_id = $this->input->post('blog_id');
				$query = $this->db->query("UPDATE `tutajua_blogs` 
				SET `blog_passwordkey`='', blog_password='".$password."', blog_passwordkey_date = '".$date."' 
				WHERE (`blog_id`='".$blog_id."') ");
				if ($this->db->affected_rows() == '1') {
					$query = $this->db->query(" INSERT INTO `tutajua_blogs_passwords` (`blog_id`, `password`, `password_date`) 
					VALUES ('".$blog_id."', '".$password."', '".$date."') ");
					if ($query){
						
						
						
						return TRUE;
					}else{
						return FALSE;
					}
				}else{
					return FALSE;
				}
			}else{
					return FALSE;
			}
			
		}
		
		function reset_password(){
			
			$blog_passwordkey =  mt_rand() . mt_rand() . mt_rand() . mt_rand() . mt_rand();
			$date =  date('Y-m-d H:m:s');
			$blog_email = $this->input->post('blog_email');
		
			if ($this->email_check($blog_email) != '') {
				$blog_id = $this->get_blog_id($blog_email);
				$query = $this->db->query("UPDATE `tutajua_blogs` 
				SET `blog_passwordkey`='".$blog_passwordkey."', blog_passwordkey_date = '".$date."' 
				WHERE (`blog_id`='".$blog_id."') ");
				if ($this->db->affected_rows() == '1') {
					return TRUE;
				}else{
					return FALSE;
				}
			}else{
					return FALSE;
			}
			
		}

		function email_check($blog_email) {
			$query = $this->db->query(" SELECT blog_email FROM tutajua_blogs WHERE blog_email = '".$blog_email."' ");
			$row = $query->row();
			if (isset($row)){
				$blog_email = $row->blog_email;
			}else{
				$blog_email = '';
			}
			return $blog_email;
		}

		function get_blog_id($blog_email) {
			$query = $this->db->query(" SELECT blog_id FROM tutajua_blogs WHERE blog_email = '".$blog_email."' ");
			$row = $query->row();
			if (isset($row)){
				$blog_id = $row->blog_id;
			}else{
				$blog_id = '';
			}
			return $blog_id;		
		}

		
		function user_details($blog_id) {
				
			$query = $this->db->query(" SELECT 
			tutajua_blogs.blog_id,
			tutajua_blogs.blog_description,
			tutajua_blogs.blog_page,
			tutajua_blogs.blog_pagetitle,
			DATE(tutajua_blogs.blog_date) AS blog_date,
			tutajua_blogs.blog_username,
			tutajua_blogs.blog_fname,
			tutajua_blogs.blog_lname,
			tutajua_blogs.blog_email,
			tutajua_blogs.blog_level,
			tutajua_blogs.blog_catergory,
			tutajua_blogs.blog_activicationkey,
			tutajua_blogs.blog_passwordkey,
			DATE(tutajua_blogs.blog_passwordkey_date) AS blog_passwordkey_date,
			tutajua_blogs.blog_logins,
			DATE(tutajua_blogs.blog_lastlogin) AS blog_lastlogin			
			FROM tutajua_blogs WHERE blog_id = '".$blog_id."' ");
			
			return $query->result_array();
				
		}		

}