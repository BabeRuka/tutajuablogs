<?php 
class Admin_dashboard extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->library('session');
				$this->load->library('unit_test');
        }
		
		function admin_details($blog_id) {
				
			$query = $this->db->query(" SELECT * FROM tutajua_blogs WHERE blog_id = '".$blog_id."' ");
			
			return $query->result_array();
				
		}		

		function all_admin_details() {
				
			$query = $this->db->query(" SELECT * FROM tutajua_blogs ");
			
			return $query->result_array();
				
		}		
		function manage_blog_details($blog_id,$blog_catergory,$blog_level) {
			
			$query = $this->db->query("UPDATE tutajua_blogs 
			SET blog_level = '".$blog_level."', blog_catergory = '".$blog_catergory."'
			WHERE blog_id = '".$blog_id."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}
		
		function update_profile_picture($blog_id, $profile_pic) {
			$query = $this->db->query(" UPDATE `tutajua_blogs` SET `blog_profile_pic` = '".$profile_pic."'
			WHERE (`blog_id` = '".$profile_pic."') "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}
		function edit_page_details($content_id) {
			$blog_content_pagetitle = htmlspecialchars($this->input->post('blog_content_pagetitle'));
			$blog_content_description = htmlspecialchars($this->input->post('blog_content_description'));
			$blog_pagetitle  = $this->input->post('blog_pagetitle');
			$blog_content_id  = $this->input->post('blog_content_id');
			$date =  date('Y-m-d H:m:s');
	
			$blog_content_page = trim(strip_tags($this->input->post('blog_content_pagetitle')));
			$blog_content_page = strtolower(str_replace("'", '', $blog_content_page));
			// Strip HTML Tags
			$blog_content_page = strip_tags($blog_content_page);
			// Clean up things like &amp;
			$blog_content_page = html_entity_decode($blog_content_page);
			// Strip out any url-encoded stuff
			$blog_content_page = urldecode($blog_content_page);
			// Replace non-AlNum characters with space
			$blog_content_page = preg_replace('/[^A-Za-z0-9]/', ' ', $blog_content_page);
			// Replace Multiple spaces with single space
			$blog_content_page = preg_replace('/ +/', ' ', $blog_content_page);
			// Trim the string of leading/trailing space
			$blog_content_page = trim($blog_content_page);
			$blog_content_page = strtolower(str_replace(' ', '-', $blog_content_page));

		
			$query = $this->db->query(" UPDATE `tutajua_blog_content` 
			SET `blog_content_description`='".$blog_content_description."', 
			`blog_content_page`='".$blog_content_page."', 
			`blog_content_pagetitle`='".$blog_content_pagetitle."', 
			`blog_content_date`='".$date."'
			WHERE (`blog_content_id`= '".$blog_content_id."' ) "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}
		function edit_blog_details($blog_id) {
			$blog_catergory= $this->input->post('blog_catergory');
			$blog_level= $this->input->post('blog_level');
			$description = htmlspecialchars($this->db->escape_str($this->input->post('blog_description')));
			$blog_pagetitle  = htmlspecialchars($this->db->escape_str($this->input->post('blog_pagetitle')));
			$query = $this->db->query("UPDATE tutajua_blogs SET
			blog_page  = '".$this->input->post('blog_page')."',   
			blog_pagetitle  = '".$blog_pagetitle."',   
			blog_username  = '".$this->input->post('blog_username')."',   
			blog_fname  = '".$this->input->post('blog_fname')."',   
			blog_lname  = '".$this->input->post('blog_lname')."',   
			blog_email  = '".$this->input->post('blog_email')."',   
			blog_description  =   '".$description."'
			WHERE blog_id = '".$blog_id."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}
		
		function delete_blog($blog_id) {
			$query = $this->db->query("DELETE FROM tutajua_blogs WHERE blog_id = '".$blog_id."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}
		function delete_page($page_id) {
			$query = $this->db->query("DELETE FROM tutajua_blog_content WHERE blog_content_id = '".$page_id."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}
		
		function edit_article_details($article_id) {
			
			$category_id = $this->input->post('blog_category_id'); 
			$category_name = $this->input->post('blog_category_name');
			//update the category 
			$update_category = $this->edit_category_name($category_id, $category_name);
			$blog_articles_level = $this->input->post('blog_articles_level');
			$blog_articles_shortdesc = htmlspecialchars($this->db->escape_str($this->input->post('blog_articles_shortdesc')));
			$blog_articles_description = htmlspecialchars($this->db->escape_str($this->input->post('blog_articles_description')));
			$blog_articles_pagetitle  = htmlspecialchars($this->input->post('blog_articles_pagetitle'));
			//update the details
			$query = $this->db->query("UPDATE tutajua_blog_articles SET
			blog_articles_page  = '".$this->input->post('blog_articles_page')."',   
			blog_articles_pagetitle  = ".$blog_articles_pagetitle.",   
			blog_articles_level  = '".$this->input->post('blog_articles_level')."',   
			blog_articles_description  =   ".$blog_articles_description.",
			blog_articles_shortdesc  =   ".$blog_articles_shortdesc."
			WHERE blog_articles_id = '".$article_id."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}		

		function edit_comments($comment_id) {

			//update the details
			$query = $this->db->query("UPDATE tutajua_blog_comments SET
			blog_comment_status  = '".$this->input->post('blog_comment_status')."'   
			WHERE blog_comment_id = '".$this->input->post('blog_comment_id')."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}	
			
		function edit_category_name($category_id, $category_name) {

			$query = $this->db->query("UPDATE tutajua_blog_categories SET
			blog_category_name  = '".$category_name."'  
			WHERE blog_category_id = '".$category_id."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}

		function edit_category($category_id, $category_name, $category_slug) {

			$query = $this->db->query("UPDATE tutajua_blog_categories SET
			blog_category_name  = '".$category_name."',  
			blog_category_slug  = '".$category_slug."'  
			WHERE blog_category_id = '".$category_id."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}
		
		function delete_article($article_id) {
			$query = $this->db->query("DELETE FROM tutajua_blog_articles 
			WHERE blog_articles_id = '".$article_id."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}
		
		function delete_comment($comment_id) {
			$query = $this->db->query("DELETE FROM tutajua_blog_comments 
			WHERE blog_comment_id = '".$comment_id."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}
		
		function delete_category($category_id) {
			$query = $this->db->query("DELETE FROM tutajua_blog_categories 
			WHERE blog_category_id = '".$category_id."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}		
			
	}