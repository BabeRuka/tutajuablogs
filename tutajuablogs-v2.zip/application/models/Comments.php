<?php 
class Comments extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->library('session');
				$this->load->library('unit_test');
        }
		function all_blog_comments() {
			//$blog_id=$_GET['blog_id'];
			$query = $this->db->query(" SELECT * FROM tutajua_blog_comments 
			WHERE blog_comment_status = 'Addressed' 
			ORDER BY blog_comment_id ASC
			LIMIT 2 ");
			
			return $query->result_array();
		
		}
		function post_comment() {
			//$blog_id=$_GET['blog_id'];

			$blog_comment_name = $this->input->post('blog_comment_name');
			$blog_comment_email = $this->input->post('blog_comment_email');
			$blog_comment_comment = $this->input->post('blog_comment_comment');
			$blog_comment_id = $this->input->post('blog_comment_id');
			$blog_articles_id = $this->input->post('blog_articles_id');
			$blog_id = $this->input->post('blog_id');
			$blog_comment_date = $this->input->post('blog_comment_date');
			$blog_comment_status = $this->input->post('blog_comment_status');
			$MM_insert = $this->input->post('MM_insert');
			$date =  date('Y-m-d H:m:s');

			$query = $this->db->query("  INSERT INTO `tutajua_blog_comments` ( `blog_articles_id`, `blog_id`, `blog_comment_date`, `blog_comment_name`, 
			`blog_comment_email`,`blog_comment_comment`, `blog_comment_status` )
			VALUES ('".$blog_articles_id."', '".$blog_id."', '".$date."', '".$blog_comment_name."', '".$blog_comment_email."', '".$blog_comment_comment."',
			 'Pending' ) ");
			if ($query ){
				return TRUE;
			}else{
				return FALSE;
			}
		
		}
		function all_comments() {
			//$blog_id=$_GET['blog_id'];
			$query = $this->db->query(" SELECT * FROM tutajua_blog_comments 
			ORDER BY blog_comment_id ASC ");
			
			return $query->result_array();
		
		}
		function get_my_comments($blog_id) {
			//$blog_id=$_GET['blog_id'];
			$query = $this->db->query(" SELECT * FROM tutajua_blog_comments 
			WHERE blog_id = '".$blog_id."'
			ORDER BY blog_comment_id ASC ");
			
			return $query->result_array();
		
		}
		function get_comment($comment_id) {
			//$blog_id=$_GET['blog_id'];
			$query = $this->db->query(" SELECT * FROM tutajua_blog_comments 
			WHERE blog_comment_id = '".$comment_id."' ");
			
			return $query->result_array();
		
		}		
		function getBlogID() {

			if ($this->uri->segment(3)){
				$blog = $this->uri->segment(3);
			}
			
			return $blog;
		}

		function getArticleID() {

			if ($this->uri->segment(4)){
				$blog = $this->uri->segment(4);
			}
			
			return $blog;
		}
		function my_blog_comment() {

			$article_id = $this->getArticleID();
			$blog_id = $this->getBlogID();

			//$blog_id=$_GET['blog_id'];
			$query = $this->db->query(" SELECT * FROM tutajua_blog_comments 
			WHERE blog_comment_status = 'Addressed'
			AND blog_articles_id = '".$article_id."'
			AND blog_id =  '".$blog_id."'
			ORDER BY blog_comment_id DESC ");
			
			return $query->result_array();
		
		}
		function get_blog_id($comment_id){
			
			$query = $this->db->query(" SELECT
			tutajua_blog_comments.blog_id
			FROM `tutajua_blog_comments`
			WHERE tutajua_blog_comments.blog_comment_id = '".$comment_id."' " );
			$row = $query->row();
			if($query){
				$blog_id = $row->blog_id; 
			}else{
				$blog_id = ''; 
			}
			return $blog_id;
		}			

}