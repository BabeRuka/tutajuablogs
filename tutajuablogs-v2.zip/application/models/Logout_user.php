<?php 
class Logout_user extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->library('session');
				$this->load->library('unit_test');
        }
		
		
		function track(){
			
			$date =  date('Y-m-d H:m:s');
			$track_session = time();
			$blog_id = $this->session->userdata('blog_id');
			$user = ''.$this->session->userdata('blog_fname').' '.$this->session->userdata('blog_lname').'';
			$track_action = 'Logout User';
			$track_ip =  $this->input->ip_address(); 
			$track_details= json_encode(array($_SERVER));
			$track_date = $date;

			$data = array(
			 'blog_id' => $blog_id, 
			 'track_action' => $track_action, 
			 'track_ip' => $track_ip, 
			 'track_session' => $track_session,
			 'track_details' => $track_details,
			 'track_date' => $track_date
 			);

			$this->db->insert('tutajua_blog_tracking', $data);
			
			return ''.$user.' was susccessfully tracked by the system';
			
		}
				
}