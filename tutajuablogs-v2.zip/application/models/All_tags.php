<?php 
class All_tags extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->library('session');
				$this->load->library('unit_test');
        }

		function update_tag($blog_id,$article_id,$blog_level) {
			
			$query = $this->db->query(" UPDATE `tutajuablogs`.`tutajua_blog_categories`
			SET `blog_category_id` = '1',
			`blog_id` = '2',
			`article_id` = '13',
			`blog_category_name` = 'Uganda Politics',
			`blog_category_slug` = 'uganda-politics'
			WHERE
			(`blog_category_id` = '1'); "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}		

		function one_tag($category_id) {
			$query = $this->db->query(" SELECT * FROM 
			tutajua_blog_categories 
			WHERE blog_category_id = '".$category_id."' ");
			return $query->result_array();
		}


		
		function insert_tag($blog_id,$article_id,$blog_tag_name,$blog_tag_slug) {
			
			$data = array(
				 'blog_id' => $blog_id, 
				 'article_id' => $article_id, 
				 'blog_tag_name' => $blog_tag_name, 
				 'blog_tag_slug' => $blog_tag_slug
			);

			$this->db->insert('tutajua_blog_tags', $data);

			
			return $result;	
		}	
		
		
	}