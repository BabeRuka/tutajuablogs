<?php 
class Articles extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->library('session');
				$this->load->library('unit_test');
        }
		function getBlogID() {

			if ($this->uri->segment(3)){
				$blog = $this->uri->segment(3);
			}
			
			return $blog;
		}

		function getArticleID() {

			if ($this->uri->segment(4)){
				$blog = $this->uri->segment(4);
			}
			
			return $blog;
		}
		function get_my_articles($blog_id){
			
			$query = $this->db->query(" SELECT * FROM tutajua_blogs, tutajua_blog_articles, tutajua_blog_categories
			WHERE tutajua_blogs.blog_id = tutajua_blog_articles.blog_id
			AND tutajua_blog_categories.article_id =  tutajua_blog_articles.blog_articles_id
			AND tutajua_blogs.blog_id ='".$blog_id."' " );
			return $query->result_array();
		}
		function get_article($article_id){
			
			$query = $this->db->query(" SELECT * FROM tutajua_blogs, tutajua_blog_articles, tutajua_blog_categories
			WHERE 	tutajua_blogs.blog_id = tutajua_blog_articles.blog_id
			AND tutajua_blog_categories.article_id =  tutajua_blog_articles.blog_articles_id
			AND blog_articles_id ='".$article_id."' " );
			return $query->result_array();
		}		
		function all_articles(){

			$query = $this->db->query(" SELECT * FROM
			tutajua_blogs,
			tutajua_blog_articles
			WHERE tutajua_blogs.blog_id = tutajua_blog_articles.blog_id
			ORDER BY tutajua_blog_articles.blog_articles_id DESC " );
			return $query->result_array();
		}
		function get_blog_id_from_article($article_id){
			
			$query = $this->db->query(" SELECT tutajua_blogs.blog_id 
			FROM tutajua_blogs
			INNER JOIN tutajua_blog_articles ON tutajua_blog_articles.blog_id = tutajua_blogs.blog_id
			WHERE tutajua_blog_articles.blog_articles_id = '".$article_id."' " );
			$row = $query->row();
			$blog_id = $row->blog_id; 

			return $blog_id;
		}		
		function get_article_title($result){
			
			$article_id = $this->getArticleID();
			$blog_id = $this->getBlogID();
	
			$query = $this->db->query(" SELECT * FROM tutajua_blogs, tutajua_blog_articles 
			WHERE tutajua_blogs.blog_id = '".$blog_id."'  
			AND tutajua_blog_articles.blog_articles_id = '".$article_id."' " );
			$row = $query->row();
			if($result = 'blog_title'){
				$title = $row->blog_pagetitle; 
			}else{
				$aarticle_title = $row->blog_articles_pagetitle; 
			}
			return $title;
		}
		
	function create_article(){
			
			$activationKey =  mt_rand() . mt_rand() . mt_rand() . mt_rand() . mt_rand();
			$date =  date('Y-m-d H:m:s');
			$blog_pagetitle = $this->input->post('article_title');
			$blog_pagetitle = str_replace("'", " ", $blog_pagetitle);
			$blog_pagetitle = str_replace('"', " ", $blog_pagetitle);
			$blog_pagetitle = str_replace(" ", "-", $blog_pagetitle);
			$blog_pagetitle = str_replace("_", "-", $blog_pagetitle);
			if  ($this->session->set_userdata('feature_image')){
				$blog_articles_image=$this->session->set_userdata('feature_image');
			}else{
				$blog_articles_image=NULL;
			}

			$data = array(
				 'blog_id' => $this->input->post('blog_id'), 
				 'blog_articles_catergory' => $this->input->post('article_catergory'), 
				 'blog_articles_shortdesc' => $this->input->post('article_shortdescription'), 
				 'blog_articles_description' => $this->input->post('article_description'), 
				 'blog_articles_page' => $blog_pagetitle, 
				 'blog_articles_pagetitle' => $this->input->post('article_title'), 
				 'blog_articles_image' => $blog_articles_image, 
				 'blog_article_date' => $date, 
				 'blog_articles_level' => 'Yet to be Administered' 
			);

			$this->db->insert('tutajua_blog_articles', $data);
			
			return $this->db->insert_id();
			
		}	
		
	function update_featured($featured_image){

			$query = $this->db->query( " UPDATE `tutajua_blog_articles`
			SET `blog_articles_image` = '".$featured_image."' 
			WHERE (`blog_articles_id` = '".$this->input->post('blog_articles_id')."') " );
			if ($query){
				return true;
			}else{
				return false;
			}
			
		}		
}