<?php 
class My_blog extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->library('session');
				$this->load->library('unit_test');
        }
		function getBlogID() {

			if ($this->uri->segment(3)){
				$blog = $this->uri->segment(3);
			}else{
				$blog = '';
			}
			
			return $blog;
		}
		
		function getMyBlogContentRows() {
				
			$blog_id=$this->getBlogID();
			$query = $this->db->query(" SELECT * FROM tutajua_blogs, tutajua_blog_articles 
			WHERE tutajua_blogs.blog_id = tutajua_blog_articles.blog_id AND tutajua_blogs.blog_id = '".$blog_id."' 
			AND tutajua_blogs.blog_level = 'Approved' 
			ORDER BY tutajua_blog_articles.blog_articles_id DESC ");
			$rowcount = $query->num_rows();	
			
			return $rowcount;
				
		}		
		function all_my_blog_content() {
			$blog_id=$this->getBlogID();
        	$query = $this->db->query(" SELECT * 
			FROM tutajua_blogs
			INNER JOIN tutajua_blog_articles ON tutajua_blog_articles.blog_id = tutajua_blogs.blog_id
			WHERE  tutajua_blogs.blog_id = '".$blog_id."' 
			AND tutajua_blogs.blog_level = 'Approved' 
			ORDER BY tutajua_blog_articles.blog_articles_id DESC ");
			
			return $query->result_array();
		}
		
		function all_my_blog_articles(){

			if ($this->uri->segment(4)){
				$page = $this->uri->segment(4);
			}else{
				$page = 1;
			}
			$blog_id=$this->getBlogID();
			$limit = $this->getLimit();
			$startpoint = ($page * $limit) - $limit;
			$limitQ = 'LIMIT '.$startpoint.', '.$limit.'';
			$query = $this->db->query( " SELECT * FROM tutajua_blogs, tutajua_blog_articles 
			WHERE tutajua_blogs.blog_id = tutajua_blog_articles.blog_id 
			AND tutajua_blogs.blog_level = 'Approved' 
			AND blog_articles_level = 'Approved' 
			AND tutajua_blogs.blog_id = ".$blog_id."
			ORDER BY tutajua_blog_articles.blog_articles_id DESC
			".$limitQ." " ) ;
			
			return $query->result_array();
		}


		function my_blog_details() {
			$blog_id=$this->getBlogID();
			$query = $this->db->query(" SELECT * FROM tutajua_blogs WHERE blog_id = '".$blog_id."' ");
			
			return $query->result_array();
		
		}
		function my_blog_title() {
			$blog_id=$this->getBlogID();
			$query = $this->db->query(" SELECT * FROM tutajua_blogs WHERE blog_id = '".$blog_id."' ");
			$row = $query->row();
			//$row['blog_pagetitle']
			return $row->blog_pagetitle;
		
		}		
		function getCurrentCount() {
		
			$limit = $this->getLimit();
			if ($this->uri->segment(4)){
				$page = $this->uri->segment(4);
				$start = $page * $limit;
				$startCount = $start - $limit;
			}else{
				$startCount = 0;
			}
			
			return $startCount;
			
		}
		function getLimit() {
			$limit = 25;
			return $limit;
			
		}		
		function getAllMylimit() {
		
			if ($this->uri->segment(4)){
				$page = $this->uri->segment(4);
			}else{
				$page = 1;
			}
			$limit = $this->getLimit();
			$limitQ = $page * $limit;
			return $limitQ;
			
		}
		function getAllRecordCount() {
		$limit = $this->getLimit();
		if ($this->uri->segment(4)){
				$page = $this->uri->segment(4);
				$current_count = $page * $limit;
			}else{
				$page = '1';
				$current_count = $limit;
			}
			
			$startpoint = ($page * $limit) - $limit;	
			$recordCount=min($startpoint + $limit, $this->getMyBlogContentRows());
			
			return $current_count; 
		}
		
		function getPagination($total, $limit, $url_joiner, $method){ 
		
				if ($this->uri->segment(4)){
					$page = $this->uri->segment(4);
				}else{
					$page = 1;
				}
				$url= 'http://'.$this->config->item('base_url').''.$url_joiner.'/'.$method.'/';       
				$total = $total;
				$adjacents = "2"; 
				$per_page = $limit ;		
		 
				$start = ($page - 1) * $per_page;                               
				 
				$prev = $page - 1;                          
				$next = $page + 1;
				$lastpage = ceil($total/$per_page);
				$lpm1 = $lastpage - 1;
				 
				$pagination = "";
				if($lastpage > 1)
				{   
					$pagination .= "<ul class='pagination'>";
							$pagination .= "<li class='details'>Page $page of $lastpage</li>";
					if ($lastpage < 7 + ($adjacents * 2))
					{   
						for ($counter = 1; $counter <= $lastpage; $counter++)
						{
							if ($counter == $page)
								$pagination.= "<li><a class='current'>$counter</a></li>";
							else
								$pagination.= "<li><a href='{$url}$counter'>$counter</a></li>";                    
						}
					}
					elseif($lastpage > 5 + ($adjacents * 2))
					{
						if($page < 1 + ($adjacents * 2))     
						{
							for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
							{
								if ($counter == $page)
									$pagination.= "<li><a class='current'>$counter</a></li>";
								else
									$pagination.= "<li><a href='{$url}$counter'>$counter</a></li>";                    
							}
							$pagination.= "<li class='dot'>...</li>";
							$pagination.= "<li><a href='{$url}$lpm1'>$lpm1</a></li>";
							$pagination.= "<li><a href='{$url}$lastpage'>$lastpage</a></li>";      
						}
						elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
						{
							$pagination.= "<li><a href='{$url}1'>1</a></li>";
							$pagination.= "<li><a href='{$url}2'>2</a></li>";
							$pagination.= "<li class='dot'>...</li>";
							for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
							{
								if ($counter == $page)
									$pagination.= "<li><a class='current'>$counter</a></li>";
								else
									$pagination.= "<li><a href='{$url}$counter'>$counter</a></li>";                    
							}
							$pagination.= "<li class='dot'>..</li>";
							$pagination.= "<li><a href='{$url}$lpm1'>$lpm1</a></li>";
							$pagination.= "<li><a href='{$url}$lastpage'>$lastpage</a></li>";      
						}
						else
						{
							$pagination.= "<li><a href='{$url}1'>1</a></li>";
							$pagination.= "<li><a href='{$url}2'>2</a></li>";
							$pagination.= "<li class='dot'>..</li>";
							for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
							{
								if ($counter == $page)
									$pagination.= "<li><a class='current'>$counter</a></li>";
								else
									$pagination.= "<li><a href='{$url}$counter'>$counter</a></li>";                    
							}
						}
					}
					 
					if ($page < $counter - 1){ 
						$pagination.= "<li><a href='{$url}$next'>Next</a></li>";
						$pagination.= "<li><a href='{$url}$lastpage'>Last</a></li>";
					}else{
						$pagination.= "<li><a class='current'>Next</a></li>";
						$pagination.= "<li><a class='current'>Last</a></li>";
					}
					$pagination.= "</ul>\n";      
				}
			 
			 
				return $pagination;
			} 		
		
}