<?php 
class Menu extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->library('session');
				$this->load->library('unit_test');
        }
		function getBlogID() {

			if ($this->uri->segment(3)){
				$blog = $this->uri->segment(3);
				
				if ( $this->uri->segment(3) == 'all' ) {
					$q=" AND blog_id IN ( SELECT blog_id FROM tutajua_blogs) "; 
				}else if( $this->uri->segment(3) == '0'  ){
					$q=" AND blog_id IN ( SELECT blog_id FROM tutajua_blogs) "; 
				}else{
					$q="AND blog_id = '".$this->uri->segment(3)."' "; 
				}				
				
			}else{
				$blog='';	
				$q=" WHERE blog_id IN (SELECT blog_id FROM tutajua_blogs) ";
			}
			
			return $blog;
		}
		function my_blog_content(){
			$blog_id=$this->getBlogID();
			if ($this->uri->segment(4)){
				$page = $this->uri->segment(4);
			}else{
				$page = 1;
			}
			if ( $this->uri->segment(3) == 'all' ) {
				$q=" AND blog_id IN ( SELECT blog_id FROM tutajua_blogs) "; 
			}else if( $this->uri->segment(3) == '0'  ){
				$q=" AND blog_id IN ( SELECT blog_id FROM tutajua_blogs) "; 
			}else{
				$q="AND blog_id = '".$this->uri->segment(3)."' "; 
			}				

			$query = $this->db->query( " SELECT * FROM tutajua_blog_content 
			WHERE blog_id != ''
			".$q."
			ORDER BY blog_content_page ASC
			LIMIT 0, 25 " ) ;
			
			return $query->result_array();
		}
		function getLimit() {
			$limit = 25;
			return $limit;	
		}
}