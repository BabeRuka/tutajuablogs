<?php 
class Outbound extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->library('session');
				$this->load->library('unit_test');
        }
		function getBlogID() {

			if ($this->uri->segment(3)){
				$blog = $this->uri->segment(3);
			}
			
			return $blog;
		}

		function getArticleID() {

			if ($this->uri->segment(4)){
				$blog = $this->uri->segment(4);
			}
			
			return $blog;
		}
		
		function article_title($article_id){
			
			$query = $this->db->query("SELECT blog_articles_pagetitle
			FROM tutajua_blog_articles 
			WHERE blog_articles_id = '".$article_id."' " );
			$rowcount = $query->num_rows();	
			$row = $query->row();
			if ($row){
				$article_title = $row->blog_articles_pagetitle; 
			}else{
				$article_title = '';
			}
			return $article_title;
		}		
		function track_article(){
			
			$outbound_id = $this->getArticleID();
			$blog_id = $this->getBlogID();
	
			$query = $this->db->query("SELECT blog_article_hits 
			FROM tutajua_blog_articles 
			WHERE blog_articles_id = '".$outbound_id."' " );
			$rowcount = $query->num_rows();	
			$row = $query->row();
			if ($row){
				$hits = $row->blog_article_hits + 1; 

				$query = $this->db->query("UPDATE tutajua_blog_articles 
				SET blog_article_hits = '".$hits."' 
				WHERE blog_articles_id = '".$outbound_id."' "); 
				$result = TRUE;
			}else{
				$result = 'FALSE';
			}
			return $result;
		}
		
}