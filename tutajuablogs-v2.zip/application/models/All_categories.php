<?php 
class All_categories extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->library('session');
				$this->load->library('unit_test');
        }

		function all_my_categories($blog_id) {

        	$query = $this->db->query(" SELECT
			blog_fname, blog_lname,tutajua_blog_categories.* 
			FROM tutajua_blog_categories
			INNER JOIN tutajua_blogs ON tutajua_blogs.blog_id = tutajua_blog_categories.blog_id
			WHERE tutajua_blog_categories.blog_id = '".$blog_id."'  ");
			
			return $query->result_array();
		}
		
		function all_categories() {

        	$query = $this->db->query(" SELECT
			blog_fname, blog_lname,tutajua_blog_categories.* 
			FROM tutajua_blog_categories
			INNER JOIN tutajua_blogs ON tutajua_blogs.blog_id = tutajua_blog_categories.blog_id
			ORDER BY blog_id ASC  ");
			
			return $query->result_array();
		}		
		function all_blog_grouped_categories() {

        	$query = $this->db->query(" SELECT
			COUNT(blog_articles_id) AS TotalArticles,
			tutajua_blog_categories.blog_category_name,
			tutajua_blog_categories.blog_category_slug,
			tutajua_blog_categories.blog_category_id
			FROM tutajua_blog_articles
			INNER JOIN tutajua_blog_categories ON tutajua_blog_articles.blog_articles_id = tutajua_blog_categories.article_id
			GROUP BY blog_category_name ");
			
			return $query->result_array();
		}
	
			function all_blog_grouped_categories_for_user($blog_id) {

        	$query = $this->db->query(" SELECT
			COUNT(blog_articles_id) AS TotalArticles,
			tutajua_blog_categories.blog_category_name,
			tutajua_blog_categories.blog_category_slug,
			tutajua_blog_categories.blog_category_id
			FROM tutajua_blog_articles
			INNER JOIN tutajua_blog_categories ON tutajua_blog_articles.blog_articles_id = tutajua_blog_categories.article_id
			WHERE tutajua_blog_categories.blog_id = '".$blog_id."'
			GROUP BY blog_category_name ");
			
			return $query->result_array();
		}
	
		function all_grouped_categories() {

			if ($this->uri->segment(4)){
				$page = $this->uri->segment(4);
			}else{
				$page = 1;
			}
			if ( $this->uri->segment(3) == 'all' ) {
				$q=''; 
			}else if( $this->uri->segment(3) == '0'  ){
				$q = '';
			}else{
				$q="AND tutajua_blog_articles.blog_id = '".$this->uri->segment(3)."' "; 
			}
			if ($this->uri->segment(4) ) {
				$qc = "AND blog_category_slug LIKE '%".$this->uri->segment(4)."%'";
			}else{
				$qc = '';
			}

        	$query = $this->db->query(" SELECT
			COUNT(blog_articles_id) AS TotalArticles,
			tutajua_blog_categories.blog_category_name,
			tutajua_blog_categories.blog_category_slug
			FROM tutajua_blog_articles
			INNER JOIN tutajua_blog_categories ON tutajua_blog_articles.blog_articles_id = tutajua_blog_categories.article_id
			".$q."
			GROUP BY blog_category_name ");
			
			return $query->result_array();
		}
		
		function all_category_articles(){

			if ( $this->uri->segment(3) == 'all' ) {
				$q=" AND tutajua_blogs.blog_id IN ( SELECT blog_id FROM tutajua_blogs) "; 
			}else if( $this->uri->segment(3) == '0'  ){
				$q=" AND tutajua_blogs.blog_id IN ( SELECT blog_id FROM tutajua_blogs) "; 
			}else{
				$q="AND tutajua_blogs.blog_id = '".$this->uri->segment(3)."' "; 
			}
			if ($this->uri->segment(4) ) {
				$qc = "AND blog_category_slug LIKE '%".$this->uri->segment(4)."%'";
			}else{
				$qc = '';
			}
			if ($this->uri->segment(4) ) {
				$qc = "AND blog_category_slug LIKE '%".$this->uri->segment(4)."%'";
			}else{
				$qc = '';
			}

			$query = $this->db->query( " SELECT *
			FROM tutajua_blogs 
			INNER JOIN tutajua_blog_articles ON tutajua_blog_articles.blog_id = tutajua_blogs.blog_id
			INNER JOIN tutajua_blog_categories ON tutajua_blog_articles.blog_articles_id = tutajua_blog_categories.article_id
			WHERE tutajua_blogs.blog_id = tutajua_blog_articles.blog_id
			AND tutajua_blogs.blog_level = 'Approved'
			AND blog_articles_level = 'Approved'
			".$q."
			".$qc."
			ORDER BY tutajua_blog_articles.blog_articles_id DESC " ) ;
			
			return $query->result_array();
		}		
		function getLimit(){
			$limit='25';
			return $limit; 	
		}


		function update_category($blog_id,$article_id,$blog_level) {
			
			$query = $this->db->query(" UPDATE `tutajuablogs`.`tutajua_blog_categories`
			SET `blog_category_id` = '1',
			`blog_id` = '2',
			`article_id` = '13',
			`blog_category_name` = 'Uganda Politics',
			`blog_category_slug` = 'uganda-politics'
			WHERE
			(`blog_category_id` = '1'); "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}		

		function one_category($category_id) {
			$query = $this->db->query(" SELECT * FROM 
			tutajua_blog_categories 
			WHERE blog_category_id = '".$category_id."' ");
			return $query->result_array();
		}


		
		function insert_category($blog_id,$article_id,$blog_category_name,$blog_category_slug) {
			
			$data = array(
				 'blog_id' => $blog_id, 
				 'article_id' => $article_id, 
				 'blog_category_name' => $blog_category_name, 
				 'blog_category_slug' => $blog_category_slug
			);
			if ($this->db->insert('tutajua_blog_categories', $data)){ 			
				return TRUE;	
			}else{
				return FALSE;	
			}
		}	
		
		
	}