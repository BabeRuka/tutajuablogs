<?php 
class Register_blog extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->helper('string');
				$this->load->library('session');
				$this->load->library('unit_test');
        }

		function register(){
			
			$activationKey =  mt_rand() . mt_rand() . mt_rand() . mt_rand() . mt_rand();
			$date =  date('Y-m-d H:m:s');
			/*$blog_username = $this->input->post('description');
			$blog_page = $this->input->post('blog_page');
			$blog_pagetitle = $this->input->post('blog_pagetitle');
			$blog_date = $this->input->post('blog_date');
			$blog_username = $this->input->post('blog_username');
			$blog_password = $this->input->post('blog_password');
			$blog_fname = $this->input->post('blog_fname');
			$blog_lname = $this->input->post('blog_lname');
			$blog_email = $this->input->post('blog_email');
			$blog_level = $this->input->post('blog_level');
			$blog_activicationkey = $activationKey;
			$blog_catergory = 'User';*/
			//$this->db->escape($title)
			$blog_pagetitle = $this->input->post('blog_pagetitle');
			$blog_page = str_replace("'", " ", $blog_pagetitle);
			$blog_page = str_replace('"', " ", $blog_pagetitle);
			$blog_page = str_replace(" ", "-", $blog_pagetitle);
			$blog_page = str_replace("_", "-", $blog_pagetitle);
			$blog_page =''.strip_quotes(strtolower($this->input->post('blog_fname'))).'-'.strip_quotes(strtolower($this->input->post('blog_lname'))).'';

			$data = array(
					'blog_username' => $this->input->post('blog_username'),
					'blog_description' => $this->input->post('blog_description'),
					'blog_page' => $blog_page,
					'blog_pagetitle' => $this->input->post('blog_pagetitle'),
					'blog_date' => $date,
					'blog_username' => $this->input->post('blog_username'),
					'blog_password' => md5($this->input->post('blog_password')),
					'blog_fname' => $this->input->post('blog_fname'),
					'blog_lname' => $this->input->post('blog_lname'),
					'blog_email' => $this->input->post('blog_email'),
					'blog_level' => $this->input->post('blog_level'),
					'blog_activicationkey' => $activationKey,
					'blog_catergory' => 'User'
			);

			$this->db->insert('tutajua_blogs', $data);
			
		}

		function username_check($str) {
			$query = $this->db->query(" SELECT * FROM tutajua_blogs WHERE blog_username = '".$str."' ");
			$row = $query->row();
			if (isset($row)){
				$blog_username = $row->blog_username;
			}else{
				$blog_username = '';
			}
			return $blog_username;
		}

		function email_check($str) {
			$query = $this->db->query(" SELECT * FROM tutajua_blogs WHERE blog_email = '".$str."' ");
			$row = $query->row();
			if (isset($row)){
				$blog_email = $row->blog_email;
			}else{
				$blog_email = '';
			}
			return $blog_email;		
		}

}