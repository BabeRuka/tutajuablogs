<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Archives extends CI_Controller {
	 
    public function __construct() {
		parent::__construct();
		$CI =& get_instance();
		$CI->load->library(array('session','user_agent'));
		$this->load->helper(array('url','form','html'));
		$this->load->model(array('all_blogs','comments','my_blog','outbound','article','archive','all_blog_archives','all_categories'));
        $this->load->helper('url_helper');
		$this->session->set_userdata('referred_from', $this->config->item('base_url').$this->input->server('REDIRECT_QUERY_STRING'));
	}


	public function index() {
		
		$blog_id = $this->article->getBlogID();	
		$blog_title = 'Archives'; //$this->article->get_article_title($result = 'blog_title');
		$data['archived_articles'] = $this->all_blog_archives->all_archives();
		$data['grouped_categories'] = $this->all_categories->all_blog_grouped_categories();
		$data['all_archives'] = $this->archive->all_archives();	
		$data['my_archives'] = $this->archive->my_archives();	
		$data['blog_id'] = $blog_id;	
		$data['title'] = $blog_title;	
		$data['my_blog_content'] = $this->my_blog->all_my_blog_content();
		$data['page_title'] = ''.$blog_title.' :: '.$blog_id.'';	
		$this->load->view('templates/frontend/header', $data);
		$this->load->view('templates/frontend/menu', $data);
		$this->load->view('archives', $data);

		$this->load->view('templates/frontend/footer', $data);
	}


	public function article() {
		
		$blog_id = $this->article->getBlogID();	
		$blog_title = 'Archives'; //
		$data['archived_articles'] = $this->archive->all_my_archived_articles();
		$data['grouped_categories'] = $this->all_categories->all_blog_grouped_categories();
		$data['all_archives'] = $this->archive->all_archives();	
		$data['my_archives'] = $this->archive->my_archives();
		$data['blog_id'] = $blog_id;	
		$data['title'] = $blog_title;	
		$data['my_blog_content'] = $this->my_blog->all_my_blog_content();
		$data['page_title'] = ''.$blog_title.' :: '.$blog_id.'';	
		$this->load->view('templates/frontend/header', $data);
		$this->load->view('templates/frontend/menu', $data);
		$this->load->view('article_archives', $data);

		$this->load->view('templates/frontend/footer', $data);
	}


	public function all() {
		
		$blog_title = 'Archives'; //
		$data['archived_articles'] = $this->archive->all_archives();
		$data['grouped_categories'] = $this->all_categories->all_blog_grouped_categories();
		$data['title'] = $blog_title;	
		$this->load->view('templates/frontend/header', $data);
		$this->load->view('templates/frontend/menu', $data);
		$this->load->view('article_archives', $data);

		$this->load->view('templates/frontend/footer', $data);
	}

}
