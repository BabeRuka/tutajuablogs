<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class All_archives extends CI_Controller {
	 
    public function __construct() {
		parent::__construct();
		$CI =& get_instance();
		$CI->load->library(array('session','user_agent'));
		$this->load->helper(array('url','form','html'));
		$this->load->model(array('all_blogs','comments','my_blog','outbound','article','all_blog_archives','all_categories'));
        $this->load->helper('url_helper');
		$this->session->set_userdata('referred_from', $this->config->item('base_url').$this->input->server('REDIRECT_QUERY_STRING'));
	}


	public function index() {
		
		$blog_title = 'Archives'; //
		$data['archived_articles'] = $this->all_blog_archives->all_archives();
		$data['archived_articles'] = $this->all_blog_archives->all_archives();
		$data['grouped_categories'] = $this->all_categories->all_blog_grouped_categories();
		$data['title'] = $blog_title;	
		$this->load->view('templates/frontend/header', $data);
		$this->load->view('templates/frontend/banner', $data);
		$this->load->view('all_archives', $data);

		$this->load->view('templates/frontend/footer', $data);
	}


	public function article() {
		$data['archived_articles'] = $this->all_blog_archives->all_archives();
		$data['grouped_categories'] = $this->all_categories->all_blog_grouped_categories();
		$blog_title = 'Archives'; //
		$data['archived_articles'] = $this->all_blog_archives->all_archives();
		$data['archives'] = $this->all_blog_archives->all_archived_articles();
		$data['title'] = $blog_title;	
		$this->load->view('templates/frontend/header', $data);
		$this->load->view('templates/frontend/blog_menu', $data);
		$this->load->view('templates/frontend/banner', $data);
		$this->load->view('all_archives', $data);
		$this->load->view('templates/frontend/right_sidebar', $data);
		$this->load->view('templates/frontend/footer', $data);
	}


	public function all() {
		
		$blog_title = 'Archives'; //
		$data['archives'] = 0;
		$data['archived_articles'] = $this->all_blog_archives->all_archives();
		$data['grouped_categories'] = $this->all_categories->all_blog_grouped_categories();
		$data['title'] = $blog_title;	
		$this->load->view('templates/frontend/header', $data);
		$this->load->view('templates/frontend/blog_menu', $data);
		$this->load->view('all_archives', $data);

		$this->load->view('templates/frontend/footer', $data);
	}

}
