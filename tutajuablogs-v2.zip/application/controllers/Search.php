<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Search extends CI_Controller {
	 
    public function __construct() {
		parent::__construct();
		$CI =& get_instance();
		$CI->load->library(array('session','user_agent','unit_test'));
		$this->load->helper(array('url','form','html'));
		$this->load->model(array('all_blogs','comments','menu','my_blog','outbound','article','all_blog_archives', 'all_categories','my_page','detailed_search'));
        $this->load->helper('url_helper');
		$this->session->set_userdata('referred_from', $this->config->item('base_url').$this->input->server('REDIRECT_QUERY_STRING'));


	}


	public function index() {
		
		$blog_id=$this->uri->segment(3,0);
		$blog_title=$this->all_blogs->my_blog_title($blog_id);
		$data['my_blog_content'] = $this->menu->my_blog_content();
		$data['blog_id'] = $blog_id;	
		//$blog_title = 'Categories'; //
		$data['grouped_categories'] = $this->all_categories->all_grouped_categories();
		$data['keyword'] = $this->detailed_search->keyword();	
		$data['detailed_search_articles'] = $this->detailed_search->detailed_search_articles(); //detailed_search_blogs
		$data['search_blogs'] = $this->detailed_search->detailed_search_blogs();
		$data['my_page'] = $this->my_page->my_page();
		$data['title'] = $blog_title;	
		$this->load->view('templates/frontend/header', $data);
		$this->load->view('templates/frontend/menu', $data);
		$this->load->view('search', $data);

		$this->load->view('templates/frontend/footer', $data);
	}




}
