<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blog extends CI_Controller {
	 
    public function __construct() {
		parent::__construct();
		$CI =& get_instance();
		$CI->load->library(array('session','user_agent'));
		$this->load->helper(array('url','form','html'));
		$this->load->model(array('all_blogs','comments','my_blog','menu','all_blog_archives','all_categories'));
        $this->load->helper('url_helper');
		$this->session->set_userdata('referred_from', $this->config->item('base_url').$this->input->server('REDIRECT_QUERY_STRING'));
	}


	public function index() {
		$data['archived_articles'] = $this->all_blog_archives->all_archives();
		$data['grouped_categories'] = $this->all_categories->all_blog_grouped_categories();
		$url = $this->config->item('base_url');
		$data['url'] = $url;	
		$data['blog_id'] = $this->my_blog->getBlogID();	
		$data['my_blog_content'] = $this->menu->my_blog_content();	
		$data['title'] = $this->my_blog->my_blog_title();		
		$data['blog_comments'] = $this->comments->all_blog_comments();	
		$data['getMyBlogContentRows'] = $this->my_blog->getMyBlogContentRows();	
		$data['my_blog_details'] = $this->my_blog->my_blog_details();	// $this->news_model->get_news();
		$data['blog_articles'] = $this->my_blog->all_my_blog_articles();	
		$data['my_blog'] = $this->my_blog->all_my_blog_content();	
		$this->load->view('templates/frontend/header', $data);
		$this->load->view('templates/frontend/menu', $data);
		$this->load->view('my_blog', $data);
		$this->load->view('templates/frontend/right_sidebar', $data);
		//var_dump($data['my_blog_content']);
		$this->load->view('templates/frontend/footer', $data);
	}


}
