<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Featured extends CI_Controller {
	 
    public function __construct() {
		parent::__construct();
		$CI =& get_instance();
		$CI->load->library(array('session','user_agent','form_validation','email'));
		$this->load->library('image_lib');
		$this->load->helper(array('url','form','html','url_helper','email'));
		$this->load->model(array('my_blog','login_user','reset_password','admin_dashboard','articles'));
		$this->session->set_userdata('referred_from', $this->config->item('base_url').$this->input->server('REDIRECT_QUERY_STRING'));

	}


	public function index() {
		$data['archived_articles'] = $this->all_blog_archives->all_archives();
		$data['grouped_categories'] = $this->all_categories->all_blog_grouped_categories();
		$data['base_url'] = $this->config->item('base_url');
		$data['admin_url'] = $this->config->item('base_url').'assets/admin/';
		$data['title'] = 'Upload Featured Imag';
		$data['error'] = '';
		$data['success'] = 'Please upload your new Featured Imag using the form below';
		$this->load->view('templates/backend/header', $data);
		$this->load->view('templates/backend/menu', $data);
		$this->load->view('templates/backend/featured_image');
		$this->load->view('templates/backend/footer', $data);
	}
	
	public function do_upload() {
		
				//upload details
				$image_name = ''.$this->input->post('blog_articles_id').'_'.time().'';	
                $config['upload_path'] = './assets/images/articles/';
                $config['allowed_types'] = 'gif|jpg|png|JPG|jpeg||JPG|PNG|GIF';
				$config['max_size'] = 2500;
				$config['min_width'] = 200;
				$config['min_height'] = 200;
				$config['max_width'] = 1280;
				$config['max_height'] = 720;
                $config['file_name'] = $image_name;
				
				$this->load->library('upload', $config);

                if (!$this->upload->do_upload('featured_image')) {
					$data['base_url'] = $this->config->item('base_url');
					$data['admin_url'] = $this->config->item('base_url').'assets/admin/';
					$data['title'] = 'Upload Featured Imag';	
					$data['success'] = 'There was an error uploading your image';
                    $error = array('error' => $this->upload->display_errors());
					$this->load->view('templates/backend/header', $data);
					$this->load->view('templates/backend/menu', $data);
                    $this->load->view('templates/backend/featured_image', $error);
					$this->load->view('templates/backend/footer', $data);
                } else {
					//save the thumb
					$file_path = $this->upload->data('upload_path');
					$orignal_file_name = $file_path.$this->upload->data('file_name'); 
					$thumb_name = $image_name.'_thumb'.$this->upload->data('file_ext');
					$new_file_name = $file_path.$thumb_name;
					//$resize_image=$this->resize_image($source_image  = $orignal_file_name, $file_name = $new_file_name, $width = 300, $height = 169);
					//save the thumbnail
					//save the featured image in the database
					$data['update'] = $this->articles->update_featured($featured_image = $this->upload->data('file_name'));
					$data['base_url'] = $this->config->item('base_url');
					$data['admin_url'] = $this->config->item('base_url').'assets/admin/';
					$data['title'] = 'Upload Featured Imag';	
					$data['success'] = 'Sccuess: Your Featured Image was successfully uploaded';
                    $data['upload_data'] = $this->upload->data();
					$this->load->view('templates/backend/header', $data);
					$this->load->view('templates/backend/menu', $data);
                    $this->load->view('templates/backend/featured_image_success', $data);
					$this->load->view('templates/backend/footer', $data);
                }
        }
	

	public function resize_image($source_image, $file_name, $width, $height) {

		$this->load->library('image_lib');
	
		$img_cfg['image_library'] = 'gd2';
		$config['source_image'] = $source_image;
		$img_cfg['maintain_ratio'] = TRUE;
		$img_cfg['create_thumb'] = TRUE;
		$img_cfg['new_image'] = $file_name;
		$img_cfg['quality'] = 100;
		$img_cfg['width'] = $width;
		$img_cfg['height'] = $height;

		$this->image_lib->resize();

	}	
	

}
