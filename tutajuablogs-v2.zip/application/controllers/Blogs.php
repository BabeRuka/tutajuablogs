<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blogs extends CI_Controller {
	 
    public function __construct() {
		parent::__construct();
		$CI =& get_instance();
		$CI->load->library(array('session','user_agent','unit_test'));
		$this->load->helper(array('url','form','html'));
		$this->load->model(array('authentication','all_blogs','comments','my_blog','all_blog_archives','all_categories'));
        $this->load->helper('url_helper');
		$this->session->set_userdata('referred_from', $this->config->item('base_url').$this->input->server('REDIRECT_QUERY_STRING'));
	}


	public function index() {
		$data['title'] = 'Welcome to TutajuaBlogs';
		$data['archived_articles'] = $this->all_blog_archives->all_archives();
		$data['grouped_categories'] = $this->all_categories->all_blog_grouped_categories();
		$data['blog_comments'] = $this->comments->all_blog_comments();	
		$data['getAllBlogContentRows'] = $this->all_blogs->getAllBlogContentRows();	
		$data['getAllRecordCount'] = $this->all_blogs->getAllRecordCount();	
		$data['getCurrentCount'] = $this->all_blogs->getCurrentCount();	
		$data['blog_articles'] = $this->all_blogs->all_blog_articles();	
		$data['blog_content'] = $this->all_blogs->all_blog_content();	
		$data['my_blog_content'] = $this->my_blog->all_my_blog_content();	
		$this->load->view('templates/frontend/header', $data);
		if (empty($this->uri->segment(3)) ) {
			$this->load->view('templates/frontend/blog_menu', $data);
		}else{
			$this->load->view('templates/frontend/banner', $data);
		}
		$this->load->view('all_blogs', $data);
		$this->load->view('templates/frontend/right_sidebar', $data);

		$this->load->view('templates/frontend/footer', $data);
	}




}
