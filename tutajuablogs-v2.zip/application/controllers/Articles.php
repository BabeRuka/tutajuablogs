<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Articles extends CI_Controller {
	 
    public function __construct() {
		parent::__construct();
		$CI =& get_instance();
		$CI->load->library(array('session','user_agent'));
		$this->load->helper(array('url','form','html'));
		$this->load->model(array('all_blogs','comments','menu','my_blog','outbound','article','all_blog_archives','all_categories'));
        $this->load->helper('url_helper');
		$this->load->model('authentication');
		$this->session->set_userdata('referred_from', $this->config->item('base_url').$this->input->server('REDIRECT_QUERY_STRING'));
	}


	public function index() {
		$data['my_blog_content'] = $this->menu->my_blog_content();
		$data['archived_articles'] = $this->all_blog_archives->all_archives();
		$data['grouped_categories'] = $this->all_categories->all_blog_grouped_categories();
		if ($this->input->post()){
			$blog_id = $this->article->getBlogID();	
			$article_id = $this->article->getArticleID();	
			$blog_title = $this->article->get_article_title($result = 'blog_title');
			$aarticle_title = $this->article->get_article_title($result = 'aarticle_title');
			$data['blog_comments'] = $this->comments->all_blog_comments();	
			$data['my_blog_comments'] = $this->comments->my_blog_comment();	
			$data['blog_id'] = $blog_id;	
			$data['article_id'] = $article_id;	
			$data['title'] = $aarticle_title;	
			$data['my_blog_content'] = $this->my_blog->all_my_blog_content();
			$data['page_title'] = ''.$aarticle_title.' :: '.$blog_id.'';	
			$data['article'] = $this->article->get_article();	
			if ($this->comments->post_comment()){
				$data['message'] = 'Your Comment was successfull posted and will appear once it has been approved by the blog owner';
			}else{
				$data['message'] = 'Your Comment wasnt successfull posted. Please try again';
			}
			$this->load->view('templates/frontend/header', $data);
			$this->load->view('templates/frontend/menu', $data);
			$this->load->view('articles', $data);
			$this->load->view('templates/frontend/right_sidebar', $data);

		}else{
			$data['archived_articles'] = $this->all_blog_archives->all_archives();
			$data['grouped_categories'] = $this->all_categories->all_blog_grouped_categories();
			$blog_id = $this->article->getBlogID();	
			$article_id = $this->article->getArticleID();	
			$blog_title = $this->article->get_article_title($result = 'blog_title');
			$aarticle_title = $this->article->get_article_title($result = 'aarticle_title');
			$data['message'] = 'Please enter your Comment below';	
			$data['blog_comments'] = $this->comments->all_blog_comments();	
			$data['my_blog_comments'] = $this->comments->my_blog_comment();	
			$data['blog_id'] = $blog_id;	
			$data['article_id'] = $article_id;	
			$data['title'] = $aarticle_title;	
			$data['my_blog_content'] = $this->my_blog->all_my_blog_content();
			$data['page_title'] = ''.$aarticle_title.' :: '.$blog_id.'';	
			$data['article'] = $this->article->get_article();	
			$this->load->view('templates/frontend/header', $data);
			$data['my_blog_content'] = $this->menu->my_blog_content();
			$this->load->view('templates/frontend/menu', $data);
			$this->load->view('articles', $data);
			$this->load->view('templates/frontend/right_sidebar', $data);
		}

		$this->load->view('templates/frontend/footer', $data);
	}




}
