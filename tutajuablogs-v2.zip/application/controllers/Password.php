<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Password extends CI_Controller {
	 
    public function __construct() {
		parent::__construct();
		$CI =& get_instance();
		$CI->load->library(array('session','user_agent','form_validation','email'));
		$this->load->helper(array('url','form','html','url_helper','email'));
		$this->load->model(array('my_blog','login_user','reset_password','all_blog_archives','all_categories'));
		$this->session->set_userdata('referred_from', $this->config->item('base_url').$this->input->server('REDIRECT_QUERY_STRING'));
	}


	public function index() {
		$data['archived_articles'] = $this->all_blog_archives->all_archives();
		$data['grouped_categories'] = $this->all_categories->all_blog_grouped_categories();
		$data['title'] = 'Reset Password';
		$data['success'] = 'Please enter your email address in order to reset your password';
		$this->load->view('templates/frontend/header', $data);
		$this->load->view('templates/frontend/blog_menu', $data);
		$this->load->view('reset_password');
		$this->load->view('templates/frontend/footer', $data);
	}
	
	public function change() {
			$data['archived_articles'] = $this->all_blog_archives->all_archives();
			$data['grouped_categories'] = $this->all_categories->all_blog_grouped_categories();
		if ($this->input->post()) {
			//there is post data and so we can go ahead
			$data['title'] = 'Reset Password';
			$valid_key = $this->uri->segment(4); 
			$blog_id = $this->uri->segment(3); 
			$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[8]', array('required' => 'Please enter a Password!!!'));
			$this->form_validation->set_rules('repeat_password', 'Password Confirmation', 'required|matches[password]' ,array('required' => 'Your Passwords must match!!!'));
			if ($this->form_validation->run() == FALSE) {
					//the key is valid and so we can change the password
					$data['title'] = 'Reset Password';
					$data['success'] = 'Please enter your new Passwords below';
					$this->load->view('templates/frontend/header', $data);
					$this->load->view('templates/frontend/blog_menu', $data);
					$this->load->view('change_password');		
			}else{
				//if both keys are valid then we can update
				if ($this->valid_code($blog_id = $_SESSION['valid_id'], $valid_key = $_SESSION['valid_key'] )){
					//we cna now update the new passwords
					$change = $this->reset_password->change();
					$data['title'] = 'Reset Password';
					$data['message'] = 'You have successfully reset your password. Please login';	
					$this->load->view('templates/frontend/header', $data);
					$this->load->view('templates/frontend/blog_menu', $data);
					$this->load->view('login_user');
				}else{
					//the key is invalid and so we post an error message
					$data['title'] = 'Reset Password';
					$data['success'] = 'The activation key you provided is either not valid or the validity has elapsed. Please enter a new key below';
					$this->load->view('templates/frontend/header', $data);
					$this->load->view('templates/frontend/blog_menu', $data);
					$this->load->view('reset_password');
				}
			}
		}else{
				if ( $this->uri->segment(3) && $this->uri->segment(4) ) {
					//the key is valid and so we can change the password
					$data['title'] = 'Reset Password';
					$data['success'] = 'Please enter your new Passwords below';
					$_SESSION['valid_id'] = $this->uri->segment(3);
					$_SESSION['valid_key'] = $this->uri->segment(4);
					$this->load->view('templates/frontend/header', $data);
					$this->load->view('templates/frontend/blog_menu', $data);
					$this->load->view('change_password');		
				}else{
					//the key is invalid and so we post an error message
					$data['title'] = 'Reset Password';
					$data['success'] = 'The activation key you provided is either not valid or the validity has elapsed. Please enter your email below to receive a valid activation key';
					$this->load->view('templates/frontend/header', $data);
					$this->load->view('templates/frontend/blog_menu', $data);
					$this->load->view('reset_password');
				}
		}
		$this->load->view('templates/frontend/footer', $data);
	}
	
	public function reset() {
		
		$this->form_validation->set_rules('blog_email', 'Email', 'required|valid_email');
		$data['archived_articles'] = $this->all_blog_archives->all_archives();
		$data['grouped_categories'] = $this->all_categories->all_blog_grouped_categories();
		
		if ($this->form_validation->run() == FALSE) {
			$data['title'] = 'Reset Password';
			$data['success'] = 'The email you entered is invalid. Please enter a valid email address';
			$this->load->view('templates/frontend/header', $data);
			$this->load->view('templates/frontend/blog_menu', $data);
			$this->load->view('reset_password');
		}else{
			
			$blog_email = $this->input->post('blog_email');
			if (!$this->email_check($blog_email)) {
				$data['title'] = 'Reset Password';
				$data['success'] = 'The email you entered is invalid. Please enter a valid email address';
				$this->load->view('templates/frontend/header', $data);
				$this->load->view('templates/frontend/blog_menu', $data);
				$this->load->view('reset_password');
			}else{
				$data['title'] = 'Reset Password';
				if ($this->reset_password->reset_password()) {
					$blog_email = $this->input->post('blog_email');
					$blog_id = $this->reset_password->get_blog_id($blog_email);
					// send an email to the user
					$user_details=$this->reset_password->user_details($blog_id);
					foreach ($user_details as $row){
						$username = ''.$row['blog_fname'].' '.$row['blog_lname'].'';
						$blog_passwordkey = $row['blog_passwordkey']; 
					}
					$subject = 'Please Reset Your Password :-)';
					$message = '
					<html>
					<head>
					  <title>Reset your Password</title>
					</head>
					<body>
					  <p>Dear '.$username.'</p>
					  <p>We received a request to reset your password to do so please click the link below.</p>
					  <p><a href="'.$this->config->item('base_url').'password/change/'.$blog_id.'/'.$blog_passwordkey.'">Click here to Reset your password</a></p>
					  <p>If you ignore the message, your password won’t be changed.</p>
					  <p>If you didn’t request a password please let us know.</p>
					  <p>Kind regards</p>
					  <p>The TutajuaBlog Team</p>
					
					</body>
					</html>
					';

					$from = str_replace('http://', 'info@', $this->config->item('base_url'));
				
					$this->email->from($from , 'Admin');
					$this->email->to($blog_email);
					
					$this->email->subject($subject);
					$this->email->message($message);
					
					$this->email->send();
					//end send an email
					$data['success'] = 'We have sent you an email with a link to reset your password.';
					$this->load->view('templates/frontend/header', $data);
					$this->load->view('templates/frontend/blog_menu', $data);
					//$this->load->view('reset_password');
				}
			}
       }
		$this->load->view('templates/frontend/footer', $data);
		
	}
	public function email_check($blog_email) {
		   $email_check = $this->reset_password->email_check($blog_email);
           if ($blog_email != $email_check ){
               return FALSE;
           }else{
               return TRUE;
           }
    }

	public function valid_code($blog_id, $valid_key) {
		   $valid_code = $this->reset_password->user_details($blog_id);
           foreach($valid_code as $row ){
			   $blog_activicationkey = $row['blog_activicationkey'];
			   $blog_passwordkey_date = $row['blog_passwordkey_date'];
           }
		   if ( ($blog_activicationkey == $valid_key) && ($blog_passwordkey_date == date('Y-m-d')) ){
			   return TRUE;
		   }else{
				return FALSE;   
		   }
		   
    }
	

	

}
