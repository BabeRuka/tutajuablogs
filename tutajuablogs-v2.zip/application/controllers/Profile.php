<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {
	 
    public function __construct() {
		parent::__construct();
		$CI =& get_instance();
		$CI->load->library(array('session','user_agent','form_validation','email'));
		$this->load->library('image_lib');
		$this->load->helper(array('url','form','html','url_helper','email'));
		$this->load->model(array('my_blog','login_user','reset_password','admin_dashboard'));
		$this->session->set_userdata('referred_from', $this->config->item('base_url').$this->input->server('REDIRECT_QUERY_STRING'));

	}


	public function index() {
		$data['base_url'] = $this->config->item('base_url');
		$data['admin_url'] = $this->config->item('base_url').'assets/admin/';
		$data['title'] = 'Upload Profile Picture';
		$data['error'] = '';
		$data['success'] = 'Please upload your new profile picture using the form below';
		$this->load->view('templates/backend/header', $data);
		$this->load->view('templates/backend/menu', $data);
		$this->load->view('templates/backend/profile_pic');
		$this->load->view('templates/backend/footer', $data);
	}
	
	public function do_upload() {
		
				//upload details	
                $config['upload_path'] = './assets/images/';
                $config['allowed_types'] = 'gif|jpg|png|JPG|jpeg||JPG|PNG|GIF';
                $config['max_size'] = 500;
                $config['min_width'] = 200;
                $config['min_height'] = 200;
                $config['max_width'] = 1624;
                $config['max_height'] = 1624;
                $config['file_name'] = ''.$this->input->post('blog_id').'_'.time().'';
				
				$this->load->library('upload', $config);

                if (!$this->upload->do_upload('profile_pic')) {
					$data['base_url'] = $this->config->item('base_url');
					$data['admin_url'] = $this->config->item('base_url').'assets/admin/';
					$data['title'] = 'Upload Profile Picture';	
					$data['success'] = 'There was an error uploading your image';
                    $error = array('error' => $this->upload->display_errors());
					$this->load->view('templates/backend/header', $data);
					$this->load->view('templates/backend/menu', $data);
                    $this->load->view('templates/backend/profile_pic', $error);
					$this->load->view('templates/backend/footer', $data);
                } else {
					$data['update'] = $this->admin_dashboard->update_profile_picture($blog_id = $this->input->post('blog_id'), $profile_pic = ''.$this->input->post('blog_id').'_'.time().''.$this->upload->data('file_ext').'');
					$data['base_url'] = $this->config->item('base_url');
					$data['admin_url'] = $this->config->item('base_url').'assets/admin/';
					$data['title'] = 'Upload Profile Picture';	
					$data['success'] = 'Sccuess: Your profile picture was successfully uploaded';
                    $data['upload_data'] = $this->upload->data();
					$this->load->view('templates/backend/header', $data);
					$this->load->view('templates/backend/menu', $data);
                    $this->load->view('templates/backend/profile_pic_success', $data);
					$this->load->view('templates/backend/footer', $data);
                }
        }
	

	

}
