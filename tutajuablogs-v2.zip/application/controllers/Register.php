<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {
	 
    public function __construct() {
		parent::__construct();
		$CI =& get_instance();
		$CI->load->library(array('session','user_agent','form_validation'));
		$this->load->helper(array('url','form','html'));
		$this->load->model(array('all_blogs','comments','my_blog','menu','register_blog','all_blog_archives','all_categories'));
        $this->load->helper('url_helper');
		$this->session->set_userdata('referred_from', $this->config->item('base_url').$this->input->server('REDIRECT_QUERY_STRING'));

	}


	public function index() {
		$data['archived_articles'] = $this->all_blog_archives->all_archives();
		$data['grouped_categories'] = $this->all_categories->all_blog_grouped_categories();
		$url = $this->config->item('base_url');
		$data['url'] = $url;	
		$data['title'] = 'Register Blog';	
		
		$this->form_validation->set_rules('blog_username', 'Username', 'trim|alpha_numeric_spaces|callback_username_check|min_length[5]|max_length[12]', array('required' => 'Please enter a Username!!!'));
        $this->form_validation->set_rules('blog_password', 'Password', 'trim|required|min_length[8]', array('required' => 'Please enter a Password!!!'));
        $this->form_validation->set_rules('blog_password_confirm', 'Password Confirmation', 'required|matches[blog_password]' ,array('required' => 'Your Passwords must match!!!'));
		$this->form_validation->set_rules('blog_email', 'Email', 'trim|callback_email_check|valid_email|is_unique[tutajua_blogs.blog_email]', array('required' => 'Please enter a valid Email Address!!!'));
		$this->form_validation->set_rules('blog_fname', 'First Name', 'trim|alpha|required', array('required' => 'Please enter your First Name!!!'));
		$this->form_validation->set_rules('blog_lname', 'Last Name', 'trim|alpha|required', array('required' => 'Please enter your Last Name!!!'));
        $this->form_validation->set_rules('blog_pagetitle', 'Blog Title', 'trim|required', array('required' => 'Please enter a title for your blog!!!'));
        $this->form_validation->set_rules('blog_description', 'Blog Description', 'trim|required', array('required' => 'Please enter a short description about your blog'));
		

		if ($this->form_validation->run() == FALSE) {
			//iof its from the admin area then we use an admin template
			if($this->input->post('registered_from') ){
				$data['title']= 'Admin Dashboard';
				$this->load->view('templates/backend/header', $data);
				$this->load->view('templates/backend/menu', $data);	
				redirect($url.'admin/blogs/create');
				$this->load->view('templates/frontend/right_sidebar', $data);			
			}else{
				$this->load->view('templates/frontend/header', $data);
				$this->load->view('templates/frontend/blog_menu', $data);
				$this->load->view('register_blog');
				$this->load->view('templates/frontend/right_sidebar', $data);
			}
			
           
        }else{
			//the form validation is successfully therefore lets upload the data
			$data['register'] = $this->register_blog->register();	
			if($this->input->post('registered_from') ){
				$data['success'] = 'Your acction was successfull';
				redirect($url.'admin/index');
			}else{
				$this->load->view('templates/frontend/header', $data);
				$this->load->view('templates/frontend/blog_menu', $data);
				$this->load->view('register_blog_success');
				$this->load->view('templates/frontend/right_sidebar', $data);
			}
        }
		
		
		$this->load->view('templates/frontend/footer', $data);
	}

	public function username_check($str) {
		   $username_check = $this->register_blog->username_check($str);
           if ($str == $username_check ){
               $this->form_validation->set_message('username_check', 'SORRY: The {field} field cannot be "'.$username_check.'". The username is already being used :-(');
               return FALSE;
           }else{
               return TRUE;
           }
    }

	public function email_check($str) {
		   $email_check = $this->register_blog->email_check($str);
           if ($str == $email_check ){
               $this->form_validation->set_message('email_check', 'SORRY: The {field} field cannot be "'.$email_check.'". The Email is already in use :-(');
               return FALSE;
           }else{
               return TRUE;
           }
    }

}
